// src/services/folderKeywordParser.js
const path = require('path');
const logger = require('../utils/logger');

class FolderKeywordParser {
  constructor() {
    // Common date patterns to strip
    this.datePatterns = [
      /^\d{4}[-_]\d{2}[-_]\d{2}[-_]/,  // YYYY-MM-DD- or YYYY_MM_DD_
      /^\d{4}[-_]\d{2}[-_]\d{2}/,       // YYYY-MM-DD or YYYY_MM_DD
      /^\d{4}[-_]\d{2}[-_]/,             // YYYY-MM- or YYYY_MM_
      /^\d{4}[-_]\d{2}/,                 // YYYY-MM or YYYY_MM
      /^\d{8}[-_]/,                      // YYYYMMDD- or YYYYMMDD_
      /^\d{8}/,                          // YYYYMMDD
      /^\d{6}[-_]/,                      // YYMMDD- or YYMMDD_
      /^\d{6}/                           // YYMMDD
    ];

    // Patterns to clean up
    this.cleanupPatterns = [
      /^\d+\s*[-_]\s*/,                  // Leading numbers like "100 - " or "01_"
      /[-_]{2,}/g,                       // Multiple dashes/underscores
      /^\s+|\s+$/g                       // Leading/trailing spaces
    ];
  }

  /**
   * Parse keywords from folder path
   * Returns: { primary, secondary, all }
   */
  parseKeywords(folderPath) {
    try {
      const parts = folderPath.split(path.sep).filter(p => p);
      
      // Get the last two parts (parent and current folder)
      const currentFolder = parts[parts.length - 1] || '';
      const parentFolder = parts[parts.length - 2] || '';

      // Parse keywords from each
      const primary = this.extractKeywords(parentFolder);
      const secondary = this.extractKeywords(currentFolder);

      // Combine all unique keywords
      const all = [...new Set([...primary, ...secondary])];

      logger.debug('Keywords parsed', { 
        folderPath, 
        primary, 
        secondary,
        all 
      });

      return {
        primary,
        secondary,
        all
      };

    } catch (error) {
      logger.error('Failed to parse keywords', { 
        folderPath, 
        error: error.message 
      });
      return {
        primary: [],
        secondary: [],
        all: []
      };
    }
  }

  /**
   * Extract keywords from a folder name
   * Strips dates, numbers, and cleans up the result
   */
  extractKeywords(folderName) {
    if (!folderName) return [];

    let cleaned = folderName;

    // Strip date patterns
    for (const pattern of this.datePatterns) {
      cleaned = cleaned.replace(pattern, '');
    }

    // Apply cleanup patterns
    for (const pattern of this.cleanupPatterns) {
      cleaned = cleaned.replace(pattern, '');
    }

    // Replace underscores and dashes with spaces
    cleaned = cleaned.replace(/[_-]+/g, ' ');

    // Normalize whitespace
    cleaned = cleaned.replace(/\s+/g, ' ').trim();

    // Skip if empty or too short
    if (!cleaned || cleaned.length < 2) {
      return [];
    }

    // Split into individual words
    const words = cleaned.split(/\s+/).filter(word => {
      // Filter out single letters and numbers
      return word.length > 1 && !/^\d+$/.test(word);
    });

    return words;
  }

  /**
   * Parse keywords from full path with multiple levels
   * Returns array of keyword sets from each folder level
   */
  parseHierarchy(folderPath) {
    try {
      const parts = folderPath.split(path.sep).filter(p => p);
      
      const hierarchy = parts.map((folder, index) => ({
        level: index,
        folder: folder,
        keywords: this.extractKeywords(folder)
      })).filter(item => item.keywords.length > 0);

      logger.debug('Hierarchy parsed', { folderPath, levels: hierarchy.length });

      return hierarchy;

    } catch (error) {
      logger.error('Failed to parse hierarchy', { 
        folderPath, 
        error: error.message 
      });
      return [];
    }
  }

  /**
   * Generate suggested keywords with confidence scores
   * Prioritizes deeper folder levels
   */
  getSuggestedKeywords(folderPath) {
    const hierarchy = this.parseHierarchy(folderPath);
    
    if (hierarchy.length === 0) {
      return [];
    }

    // Weight keywords based on depth (deeper = more specific = higher weight)
    const weighted = [];
    
    hierarchy.forEach((level, index) => {
      const weight = (index + 1) / hierarchy.length; // 0.33, 0.67, 1.0 for 3 levels
      
      level.keywords.forEach(keyword => {
        weighted.push({
          keyword: keyword.toLowerCase(),
          confidence: Math.round(weight * 100),
          source: level.folder
        });
      });
    });

    // Deduplicate, keeping highest confidence
    const unique = new Map();
    weighted.forEach(item => {
      if (!unique.has(item.keyword) || unique.get(item.keyword).confidence < item.confidence) {
        unique.set(item.keyword, item);
      }
    });

    // Sort by confidence (descending)
    const suggestions = Array.from(unique.values())
      .sort((a, b) => b.confidence - a.confidence);

    logger.debug('Suggested keywords generated', { 
      folderPath, 
      count: suggestions.length 
    });

    return suggestions;
  }

  /**
   * Format keywords for AI prompt
   * Returns comma-separated string
   */
  formatForPrompt(folderPath) {
    const { all } = this.parseKeywords(folderPath);
    return all.join(', ');
  }

  /**
   * Test cases for keyword extraction
   */
  static testExtraction() {
    const parser = new FolderKeywordParser();
    
    const testCases = [
      '2011_11_21_Chernobyl_Pripyat',
      '2011_11_21_Chernobyl_Pripyat/100 - Reactor 1-4 Exterior',
      '2011_09_21_Beer Glass',
      'YYYY-MM-DD/Project Name/Subfolder',
      '2023-05-15_Product_Photography',
      '20230515_Event_Photos'
    ];

    console.log('\n=== Folder Keyword Parser Tests ===\n');
    testCases.forEach(testCase => {
      const result = parser.parseKeywords(testCase);
      console.log(`Input: ${testCase}`);
      console.log(`Primary: [${result.primary.join(', ')}]`);
      console.log(`Secondary: [${result.secondary.join(', ')}]`);
      console.log(`All: [${result.all.join(', ')}]`);
      console.log('');
    });
  }
}

module.exports = FolderKeywordParser;


