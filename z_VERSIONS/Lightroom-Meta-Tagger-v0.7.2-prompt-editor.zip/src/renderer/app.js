// ============================================
// DEBUG: Verify script loaded
// ============================================
console.log('====================================');
console.log('APP.JS LOADED - TIMESTAMP:', new Date().toISOString());
console.log('====================================');

let selectedDirectory = null;
let scanResults = null;

// Pagination state
let currentPage = 1;
let rowsPerPage = 10;
let allClusters = [];

// Prompt editing state
let customPrompts = new Map(); // Map of representativePath -> customPrompt
let currentPromptCluster = null; // Currently editing cluster

// UI Elements - Will be initialized after DOM loads
let selectDirBtn;
let dropzone;
let resultsTable;
let resultsTableBody;
let processImagesBtn;
let totalFilesEl;
let filesToProcessEl;
let progressFill;
let progressText;

// ============================================
// Initialize after DOM is ready
// ============================================
window.addEventListener('DOMContentLoaded', () => {
  console.log('DOM Content Loaded - Now initializing elements...');
  
  // Get all DOM elements
  selectDirBtn = document.getElementById('selectDirBtn');
  dropzone = document.getElementById('dropzone');
  resultsTable = document.getElementById('resultsTable');
  resultsTableBody = document.getElementById('resultsTableBody');
  processImagesBtn = document.getElementById('processImagesBtn');
  totalFilesEl = document.getElementById('totalFiles');
  filesToProcessEl = document.getElementById('filesToProcess');
  progressFill = document.getElementById('progressFill');
  progressText = document.getElementById('progressText');

  console.log('DEBUG: Element check after DOM load:');
  console.log('  selectDirBtn:', selectDirBtn);
  console.log('  dropzone:', dropzone);
  console.log('  resultsTable:', resultsTable);
  
  // Initialize all event listeners
  initializeEventListeners();
  
  // Check database on startup
  checkDatabaseOnStartup();
});

// Initialize modal listeners AFTER full page load (including modal HTML)
window.addEventListener('load', () => {
  console.log('🎬 Full page loaded - Initializing modal listeners...');
  initializeModalListeners();
});

// ============================================
// Event Listener Initialization
// ============================================
function initializeEventListeners() {
  console.log('Initializing event listeners...');
  
  // Tab switching
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabName = button.dataset.tab;
      
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanels.forEach(panel => panel.classList.remove('active'));
      
      button.classList.add('active');
      document.getElementById(`${tabName}-tab`).classList.add('active');
    });
  });

  // Analysis tab switching (AI Generated vs Database Match)
  const analysisTabButtons = document.querySelectorAll('.analysis-tab-btn');
  const analysisTabContents = document.querySelectorAll('.analysis-tab-content');

  analysisTabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabName = button.dataset.tab;
      
      // Update button states
      analysisTabButtons.forEach(btn => {
        btn.classList.remove('active');
        btn.style.borderBottom = '3px solid transparent';
        btn.style.color = '#666';
      });
      
      // Update content visibility
      analysisTabContents.forEach(content => {
        content.style.display = 'none';
      });
      
      // Activate selected tab
      button.classList.add('active');
      button.style.borderBottom = '3px solid #3498db';
      button.style.color = '#3498db';
      
      // Show selected content
      if (tabName === 'ai-generated') {
        document.getElementById('aiGeneratedContent').style.display = 'block';
      }
    });
  });

  // Select directory button
  if (selectDirBtn) {
    console.log('DEBUG: Adding click listener to selectDirBtn');
    selectDirBtn.addEventListener('click', async () => {
      console.log('==== BUTTON CLICKED ====');
      try {
        await selectAndScanDirectory();
      } catch (error) {
        console.error('ERROR in button click handler:', error);
      }
    });
    console.log('✅ Select button listener attached');
  } else {
    console.error('CRITICAL ERROR: selectDirBtn is NULL after DOM load!');
  }

  // Dropzone event listeners
  if (dropzone) {
    console.log('DEBUG: Adding event listeners to dropzone');
    
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('dragover');
    });
    
    dropzone.addEventListener('dragleave', () => {
      dropzone.classList.remove('dragover');
    });

    dropzone.addEventListener('drop', async (e) => {
      e.preventDefault();
      dropzone.classList.remove('dragover');
      
      const files = e.dataTransfer.files;
      
      if (files.length > 0) {
        // In Electron, files[0].path gives the absolute file system path
        const droppedPath = files[0].path;
        console.log('Dropped path:', droppedPath);
        
        // Determine if it's a directory or file (await since it's now an IPC call)
        let dirToScan;
        const isDir = await window.electronAPI.isDirectory(droppedPath);
        if (isDir) {
          dirToScan = droppedPath;
          console.log('Directory dropped, scanning:', dirToScan);
        } else {
          dirToScan = await window.electronAPI.getParentDir(droppedPath);
          console.log('File dropped, scanning parent directory:', dirToScan);
        }
        
        // Scan the directory
        await selectAndScanDirectory(dirToScan);
      }
    });

    dropzone.addEventListener('click', async (e) => {
      console.log('Dropzone clicked, target:', e.target.id);
      if (e.target.id !== 'selectDirBtn') {
        console.log('Triggering selectAndScanDirectory from dropzone click');
        await selectAndScanDirectory();
      }
    });
    console.log('✅ Dropzone listeners attached');
  } else {
    console.error('CRITICAL ERROR: dropzone is NULL after DOM load!');
  }
  
  // Process Images button
  if (processImagesBtn) {
    processImagesBtn.addEventListener('click', async () => {
      await processImages();
    });
    console.log('✅ Process button listener attached');
  }
  
  // Settings tab event listeners
  const selectDbBtn = document.getElementById('selectDbBtn');
  const clearDbBtn = document.getElementById('clearDbBtn');
  const settingsTab = document.querySelector('[data-tab="settings"]');
  
  if (selectDbBtn) {
    selectDbBtn.addEventListener('click', handleSelectDatabase);
    console.log('✅ Settings database button listener attached');
  }
  
  if (clearDbBtn) {
    clearDbBtn.addEventListener('click', handleClearDatabase);
    console.log('✅ Clear database button listener attached');
  }
  
  if (settingsTab) {
    settingsTab.addEventListener('click', () => {
      loadSettings();
    });
    console.log('✅ Settings tab listener attached');
  }

  // Results tab event listeners
  const resultsTab = document.querySelector('[data-tab="results"]');
  if (resultsTab) {
    resultsTab.addEventListener('click', () => {
      loadProcessedResults();
    });
    console.log('✅ Results tab listener attached');
  }
  
  // AI Settings event listeners
  const saveAISettingsBtn = document.getElementById('saveAISettingsBtn');
  const testGoogleVisionBtn = document.getElementById('testGoogleVisionBtn');
  const toggleApiKeyVisibility = document.getElementById('toggleApiKeyVisibility');

  if (saveAISettingsBtn) {
    saveAISettingsBtn.addEventListener('click', handleSaveAISettings);
    console.log('✅ Save AI settings button listener attached');
  }

  if (testGoogleVisionBtn) {
    testGoogleVisionBtn.addEventListener('click', handleTestGoogleVision);
    console.log('✅ Test Google Vision button listener attached');
  }

  if (toggleApiKeyVisibility) {
    toggleApiKeyVisibility.addEventListener('click', () => {
      const apiKeyInput = document.getElementById('googleVisionApiKey');
      if (apiKeyInput) {
        apiKeyInput.type = apiKeyInput.type === 'password' ? 'text' : 'password';
      }
    });
    console.log('✅ Toggle API key visibility listener attached');
  }

  // Personal Data tab listener
  const personalDataTab = document.querySelector('[data-tab="personal-data"]');
  if (personalDataTab) {
    personalDataTab.addEventListener('click', () => {
      console.log('✅ Personal Data tab clicked');
      loadPersonalData(); // Load saved data when tab opens
    });
    console.log('✅ Personal Data tab listener attached');
  }

  // Save Personal Data button
  const savePersonalDataBtn = document.getElementById('savePersonalDataBtn');
  if (savePersonalDataBtn) {
    savePersonalDataBtn.addEventListener('click', savePersonalData);
    console.log('✅ Save Personal Data button listener attached');
  }
  
  // Run Analysis button (Visual Analysis tab)
  const runAnalysisBtn = document.getElementById('runAnalysisBtn');
  if (runAnalysisBtn) {
    runAnalysisBtn.addEventListener('click', async () => {
      if (!allProcessedImages || allProcessedImages.length === 0) {
        alert('No processed images available to analyze');
        return;
      }
      
      
      // Disable button during analysis
      runAnalysisBtn.disabled = true;
      runAnalysisBtn.textContent = 'Analyzing...';
      
      // Batch analyze all clusters
      await batchAnalyzeAllClusters();
      
      // Re-enable button
      runAnalysisBtn.disabled = false;
      runAnalysisBtn.innerHTML = `
        <svg class="ai-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 2L2 7l10 5 10-5-10-5z"/>
          <path d="M2 17l10 5 10-5"/>
          <path d="M2 12l10 5 10-5"/>
        </svg>
        Run AI Analysis
      `;
      
      // Switch to AI Analysis tab to view results
      const aiAnalysisTab = document.querySelector('[data-tab="ai-analysis"]');
      if (aiAnalysisTab) {
        aiAnalysisTab.click();
      }
    });
    console.log('✅ Run Analysis button listener attached');
  }
  
  // Initialize AI Analysis listeners
  initializeAIAnalysisListeners();
  
  console.log('✅ All event listeners initialized successfully!');
}

// ============================================
// Main Scan Function
// ============================================
async function selectAndScanDirectory(dirPath = null) {
  console.log('==== selectAndScanDirectory CALLED ====');
  
  try {
    // If dirPath is provided (from drag & drop), use it directly
    if (dirPath) {
      console.log('Using provided directory path:', dirPath);
      selectedDirectory = dirPath;
    } else {
      // Otherwise, show directory selection dialog
      console.log('Step 1: Calling selectDirectory...');
      const result = await window.electronAPI.selectDirectory();
      console.log('Step 2: Directory result:', result);
      
      if (result.canceled) {
        console.log('Step 3: User canceled selection');
        return;
      }
      
      selectedDirectory = result.path;
      console.log('Step 4: Selected directory:', selectedDirectory);
    }
    
    // Update status
    console.log('Step 5: Updating UI status...');
    updateStatus('Scanning directory and analyzing timestamps...', 'scanning');
    showProgress(10);
    
    console.log('Step 6: Starting scan with clustering...');
    
    // Perform scan WITH CLUSTERING (5 second threshold)
    const response = await window.electronAPI.scanDirectoryWithClustering(
      selectedDirectory,
      5  // 5 second threshold for bracketed shots
    );
    
    console.log('Step 7: Scan response received:', response);
    
    showProgress(100);
    
    if (!response.success) {
      throw new Error(response.error);
    }
    
    scanResults = response.results;
    const summary = response.summary;
    
    // Store globally for processing
    window.scanResults = scanResults;
    window.selectedDirectory = selectedDirectory;
    
    console.log('Step 8: Scan results:', scanResults);
    console.log('Step 9: Summary:', summary);
    console.log('Step 9b: Stored globally:', { 
      hasScanResults: !!window.scanResults, 
      hasSelectedDir: !!window.selectedDirectory 
    });
    
    // Update UI with results
    displayScanResults(summary);
    populateResultsTableWithClusters(scanResults);
    
    updateStatus('Scan complete with timestamp clustering!', 'ready');
    
    // Enable the process button
    if (processImagesBtn) {
      processImagesBtn.disabled = false;
    }
    
    console.log('Step 10: UI updated successfully!');
    
  } catch (error) {
    console.error('ERROR in selectAndScanDirectory:', error);
    updateStatus(`Error: ${error.message}`, 'error');
    showProgress(0);
  }
}

// ============================================
// Helper Functions
// ============================================

// Update status display
function updateStatus(message, status = 'pending') {
  console.log(`[${status}] ${message}`);
}

// Update progress bar
function showProgress(percent) {
  progressFill.style.width = `${percent}%`;
  progressText.textContent = `${percent}%`;
}

// Display scan summary in status panel
function displayScanResults(summary) {
  // DEBUG: Log what we're receiving
  console.log('displayScanResults summary:', summary);
  console.log('totalFiles:', summary.totalFiles, 'type:', typeof summary.totalFiles);
  console.log('totalBaseImages:', summary.totalBaseImages, 'type:', typeof summary.totalBaseImages);
  console.log('totalDerivatives:', summary.totalDerivatives, 'type:', typeof summary.totalDerivatives);
  
  // Ensure numeric addition, not string concatenation
  const totalFiles = Number(summary.totalFiles) || (Number(summary.totalBaseImages) + Number(summary.totalDerivatives));
  console.log('Calculated totalFiles:', totalFiles);
  totalFilesEl.textContent = totalFiles;
  filesToProcessEl.textContent = summary.totalClusters || summary.totalBaseImages;
  
  // Add clustering info if available
  if (summary.totalClusters) {
    // Check if cluster info already exists
    let clusterInfo = document.querySelector('.cluster-info');
    if (!clusterInfo) {
      clusterInfo = document.createElement('div');
      clusterInfo.className = 'cluster-info';
      document.querySelector('.status-grid').appendChild(clusterInfo);
    }
    
    clusterInfo.innerHTML = `
      <div class="status-item">
        <span class="status-label">Bracketed Groups:</span>
        <span class="status-value">${summary.bracketedClusters}</span>
      </div>
      <div class="status-item">
        <span class="status-label">Single Images:</span>
        <span class="status-value">${summary.singletonClusters}</span>
      </div>
    `;
  }
  
  // Show the results table
  resultsTable.style.display = 'block';
}

// ============================================
// PHASE 2: Process Images Function
// ============================================
async function processImages() {
  try {
    console.log('Process Images clicked!');
    
    // Validate that we have scan results
    if (!window.scanResults || !window.selectedDirectory) {
      alert('Please scan a directory first before processing images.');
      return;
    }

    // Disable button during processing
    if (processImagesBtn) {
      processImagesBtn.disabled = true;
      processImagesBtn.style.display = 'flex';
      processImagesBtn.textContent = 'Processing...';
    }

    // Update progress
    updateStatus('Processing images...', 'processing');
    showProgress(0);

    console.log('Starting image processing...', {
      clusters: window.scanResults.clusters?.length,
      directory: window.selectedDirectory
    });

    // Call the backend processing pipeline
    console.log('=== CALLING processImages IPC ===');
    console.log('Arguments:', { 
      scanResults: !!window.scanResults, 
      dirPath: window.selectedDirectory
    });
    
    const result = await window.electronAPI.processImages(
      window.scanResults,
      window.selectedDirectory
    );
    
    console.log('=== processImages IPC COMPLETED ===');

    console.log('Processing complete:', result);

    if (result.success) {
      updateStatus('Processing complete!', 'complete');
      showProgress(100);
      
      // Store processed clusters and similarity results globally for Results tab
      window.processedClusters = result.processedClusters;
      window.similarityResults = result.similarityResults || [];
      
      // ============================================================================
      // 🔍 STEP 1: AFTER BACKEND PROCESSING - Track derivatives from backend
      // ============================================================================
      console.log('\n🔍 ========== STEP 1: AFTER BACKEND PROCESSING ==========');
      console.log(`window.processedClusters count: ${window.processedClusters.length}`);
      let step1Derivs = 0;
      let step1Files = 0;
      window.processedClusters.forEach((c, idx) => {
        const derivCount = c.derivatives?.length || 0;
        const imageCount = c.imagePaths?.length || 0;
        step1Derivs += derivCount;
        step1Files += imageCount;
        console.log(`[${idx}] ${c.representativeFilename}`);
        console.log(`     imagePaths: ${imageCount}, derivatives: ${derivCount}`);
        if (derivCount > 0) {
          c.derivatives.forEach(d => console.log(`       - ${d.split('/').pop()}`));
        }
      });
      console.log(`📊 Total after backend: ${window.processedClusters.length} reps + ${step1Files} images + ${step1Derivs} derivatives`);
      console.log(`📊 GRAND TOTAL: ${window.processedClusters.length + step1Files + step1Derivs} files`);
      console.log(`📊 EXPECTED: 78 files`);
      console.log(`📊 DIFFERENCE: ${78 - (window.processedClusters.length + step1Files + step1Derivs)} files ${78 - (window.processedClusters.length + step1Files + step1Derivs) > 0 ? 'MISSING' : 'EXTRA'}`);
      console.log('🔍 ==========================================\n');
      // ============================================================================
      
      // 🔍 DEBUG: Log similarity data stored in window
      console.log('🔍 ===== SIMILARITY DATA STORED IN WINDOW =====');
      console.log(`📊 window.similarityResults length: ${window.similarityResults?.length || 0}`);
      if (window.similarityResults && window.similarityResults.length > 0) {
        console.log('📋 First pair:', window.similarityResults[0]);
      }
      console.log('🔍 ==========================================\n');
      
      // Switch to Results tab directly (no alert popup)
      const resultsTab = document.querySelector('[data-tab="results"]');
      if (resultsTab) {
        resultsTab.click();
      }

    } else {
      throw new Error(result.error || 'Processing failed');
    }

  } catch (error) {
    console.error('Process images failed:', error);
    updateStatus(`Processing failed: ${error.message}`, 'error');
    alert(`Processing failed: ${error.message}`);
  } finally {
    // Re-enable button
    if (processImagesBtn) {
      processImagesBtn.disabled = false;
      processImagesBtn.innerHTML = `
        <svg class="process-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <circle cx="12" cy="12" r="10"/>
          <path d="M12 6v6l4 2"/>
        </svg>
        Process Images
      `;
    }
  }
}

// Listen for progress updates from backend
if (window.electronAPI && window.electronAPI.onProgress) {
  window.electronAPI.onProgress((progressData) => {
    console.log('Progress update:', progressData);
    
    if (progressData.percent !== undefined) {
      showProgress(progressData.percent);
    }
    
    if (progressData.message) {
      updateStatus(progressData.message, progressData.stage || 'processing');
    }
  });
}

// Populate the results table (fallback method for non-clustered data)
function populateResultsTable(results) {
  resultsTableBody.innerHTML = '';
  
  const sortedBases = Object.keys(results.derivatives).sort();
  
  sortedBases.forEach(baseImage => {
    const derivatives = results.derivatives[baseImage];
    const row = createTableRow(baseImage, derivatives);
    resultsTableBody.appendChild(row);
  });
  
  // Show table wrapper, hide pagination controls
  document.getElementById('tableWrapper').style.display = 'block';
  document.getElementById('paginationTop').style.display = 'none';
  document.getElementById('paginationBottom').style.display = 'none';
}

// Create a simple table row
function createTableRow(baseImagePath, derivatives) {
  const row = document.createElement('tr');
  
  const pathParts = baseImagePath.split('/');
  const filename = pathParts[pathParts.length - 1];
  const directory = pathParts.slice(0, -1).join('/');
  
  // Parent Image column
  const parentCell = document.createElement('td');
  
  // Filename on first line
  const parentText = document.createElement('div');
  parentText.className = 'parent-image';
  parentText.textContent = filename;
  
  // Count on second line (if derivatives exist)
  if (derivatives.length > 0) {
    const countDiv = document.createElement('div');
    countDiv.className = 'parent-count';
    countDiv.textContent = `${derivatives.length} derivative${derivatives.length > 1 ? 's' : ''}`;
    parentCell.appendChild(parentText);
    parentCell.appendChild(countDiv);
  } else {
    parentCell.appendChild(parentText);
  }
  
  // Child Images column
  const childCell = document.createElement('td');
  childCell.className = 'child-images';
  
  if (derivatives.length === 0) {
    childCell.textContent = '—';
  } else {
    derivatives.forEach(derivPath => {
      const derivName = derivPath.split('/').pop();
      const badge = document.createElement('span');
      badge.className = 'child-image-item derivative-badge';
      badge.textContent = derivName;
      badge.title = 'Edited derivative';
      childCell.appendChild(badge);
    });
  }
  
  // Status column
  const statusCell = document.createElement('td');
  const statusBadge = document.createElement('span');
  statusBadge.className = 'status-badge status-ready';
  statusBadge.textContent = 'Ready';
  statusCell.appendChild(statusBadge);
  
  // Append all cells
  row.appendChild(parentCell);
  row.appendChild(childCell);
  row.appendChild(statusCell);
  
  return row;
}

// Populate the results table with clustered data
function populateResultsTableWithClusters(results) {
  console.log('=== POPULATE TABLE DEBUG ===');
  console.log('Total clusters received:', results.clusters ? results.clusters.length : 0);
  
  // Debug: Show first cluster sample
  if (results.clusters && results.clusters.length > 0) {
    console.log('First cluster sample:', results.clusters[0]);
    console.log('Representative field:', results.clusters[0].representative);
    console.log('ImagePaths field:', results.clusters[0].imagePaths);
    console.log('Images field:', results.clusters[0].images);
  }
  
  // Store scan results globally for pagination
  window.scanResults = results;
  allClusters = results.clusters || [];
  currentPage = 1;
  
  if (allClusters.length === 0) {
    console.log('No clusters found, using fallback table method');
    populateResultsTable(results);
    return;
  }
  
  console.log('Starting paginated rendering...');
  
  // Render first page
  renderPage();
  setupPaginationControls();
  
  // Show pagination and table
  document.getElementById('paginationTop').style.display = 'flex';
  document.getElementById('paginationBottom').style.display = 'flex';
  document.getElementById('tableWrapper').style.display = 'block';
  
  console.log('=== END TABLE DEBUG ===');
}

// Render current page of results
function renderPage() {
  resultsTableBody.innerHTML = '';
  
  const start = (currentPage - 1) * rowsPerPage;
  const end = Math.min(start + rowsPerPage, allClusters.length);
  const pageRows = allClusters.slice(start, end);
  
  console.log(`Rendering page ${currentPage}: rows ${start + 1} to ${end}`);
  
  // Enhanced debug logging
  console.log('=== RENDERING DEBUG ===');
  pageRows.forEach((cluster, idx) => {
    console.log(`Row ${idx}:`, {
      representative: cluster.representative,
      imageCount: cluster.imageCount,
      images: cluster.images,
      isBracketed: cluster.isBracketed
    });
  });
  
  pageRows.forEach(cluster => {
    const row = createClusterTableRow(cluster, window.scanResults || { derivatives: {} });
    console.log('Row created, HTML length:', row.outerHTML.length);
    console.log('Row HTML preview:', row.outerHTML.substring(0, 200));
    resultsTableBody.appendChild(row);
  });
  
  console.log('Total rows in tbody after render:', resultsTableBody.children.length);
  console.log('Tbody display style:', resultsTableBody.parentElement.style.display);
  console.log('=== END RENDERING ===');
  
  updatePaginationInfo();
}

// Update pagination display
function updatePaginationInfo() {
  const start = (currentPage - 1) * rowsPerPage + 1;
  const end = Math.min(currentPage * rowsPerPage, allClusters.length);
  const total = allClusters.length;
  const info = `Showing ${start}-${end} of ${total}`;
  
  document.getElementById('pageInfoTop').textContent = info;
  document.getElementById('pageInfoBottom').textContent = info;
  
  const totalPages = Math.ceil(total / rowsPerPage);
  
  // Enable/disable buttons
  ['Top', 'Bottom'].forEach(suffix => {
    document.getElementById(`firstPage${suffix}`).disabled = currentPage === 1;
    document.getElementById(`prevPage${suffix}`).disabled = currentPage === 1;
    document.getElementById(`nextPage${suffix}`).disabled = currentPage === totalPages;
    document.getElementById(`lastPage${suffix}`).disabled = currentPage === totalPages;
  });
}

// Setup pagination button handlers
function setupPaginationControls() {
  ['Top', 'Bottom'].forEach(suffix => {
    document.getElementById(`firstPage${suffix}`).onclick = () => {
      currentPage = 1;
      renderPage();
    };
    
    document.getElementById(`prevPage${suffix}`).onclick = () => {
      if (currentPage > 1) {
        currentPage--;
        renderPage();
      }
    };
    
    document.getElementById(`nextPage${suffix}`).onclick = () => {
      const totalPages = Math.ceil(allClusters.length / rowsPerPage);
      if (currentPage < totalPages) {
        currentPage++;
        renderPage();
      }
    };
    
    document.getElementById(`lastPage${suffix}`).onclick = () => {
      currentPage = Math.ceil(allClusters.length / rowsPerPage);
      renderPage();
    };
  });
}

// Create a table row for a cluster
function createClusterTableRow(cluster, allResults) {
  const row = document.createElement('tr');
  
  if (cluster.isBracketed) {
    row.classList.add('bracketed-row');
  }
  
  // Extract just the filename from the full path
  const representativePath = cluster.representative;
  const representativeFilename = representativePath.split('/').pop();
  
  // Pre-calculate derivatives for ALL images in cluster (used in multiple places)
  const allDerivatives = [];
  cluster.imagePaths.forEach(imagePath => {
    const derivs = allResults.derivatives[imagePath] || [];
    allDerivatives.push(...derivs);
  });
  
  // Parent Image column
  const parentCell = document.createElement('td');
  
  // Filename on first line
  const parentText = document.createElement('div');
  parentText.className = 'parent-image';
  parentText.textContent = representativeFilename;
  
  // Count bracketed images and derivatives
  const bracketedCount = cluster.imageCount > 1 ? cluster.imageCount : 0;
  const derivativeCount = allDerivatives.length;
  
  // Build count string
  const countParts = [];
  if (bracketedCount > 0) {
    countParts.push(`${bracketedCount} bracketed`);
  }
  if (derivativeCount > 0) {
    countParts.push(`${derivativeCount} derivatives`);
  }
  
  // Count on second line
  if (countParts.length > 0) {
    const countDiv = document.createElement('div');
    countDiv.className = 'parent-count';
    countDiv.textContent = countParts.join(', ');
    parentCell.appendChild(parentText);
    parentCell.appendChild(countDiv);
  } else {
    parentCell.appendChild(parentText);
  }
  
  // Child Images column
  const childCell = document.createElement('td');
  childCell.className = 'child-images';
  
  if (cluster.isBracketed) {
    // ✅ FIX: Use imagePaths and extract just the filename
    const imagesToDisplay = cluster.imagePaths || cluster.images;
    
    imagesToDisplay.forEach(imagePath => {
      // Skip the representative
      if (imagePath === cluster.representative || imagePath === cluster.representativePath) {
        return;
      }
      
      const badge = document.createElement('span');
      badge.className = 'child-image-item bracketed-badge';
      badge.textContent = imagePath.split('/').pop(); // ✅ Extract just filename
      badge.title = 'Bracketed shot';
      childCell.appendChild(badge);
    });
  }
  
  // Render derivative badges (allDerivatives already calculated above)
  if (allDerivatives.length > 0) {
    allDerivatives.forEach(derivPath => {
      const derivName = derivPath.split('/').pop();
      const badge = document.createElement('span');
      badge.className = 'child-image-item derivative-badge';
      badge.textContent = derivName;
      badge.title = 'Edited derivative';
      childCell.appendChild(badge);
    });
  }
  
  if (!cluster.isBracketed && allDerivatives.length === 0) {
    childCell.textContent = '—';
  }
  
  // Status column
  const statusCell = document.createElement('td');
  const statusBadge = document.createElement('span');
  statusBadge.className = 'status-badge status-ready';
  statusBadge.textContent = cluster.isBracketed ? 'Bracketed Ready' : 'Ready';
  statusCell.appendChild(statusBadge);
  
  // Append all cells
  row.appendChild(parentCell);
  row.appendChild(childCell);
  row.appendChild(statusCell);
  
  return row;
}


// ============================================
// Settings Tab Functionality
// ============================================

async function loadSettings() {
  try {
    const settings = await window.electronAPI.getAllSettings();
    
    // Database settings
    const dbPathInput = document.getElementById('dbPath');
    if (settings.databasePath && dbPathInput) {
      dbPathInput.value = settings.databasePath;
    }
    
    const thresholdInput = document.getElementById('timestampThreshold');
    if (thresholdInput) {
      thresholdInput.value = settings.timestampThreshold || 5;
    }
    
    // AI Analysis settings
    const ollamaEndpoint = document.getElementById('ollamaEndpoint');
    const ollamaModel = document.getElementById('ollamaModel');
    const confidenceThreshold = document.getElementById('confidenceThreshold');
    const googleVisionApiKey = document.getElementById('googleVisionApiKey');
    
    if (ollamaEndpoint) ollamaEndpoint.value = settings.ollama?.endpoint || 'http://localhost:11434';
    if (ollamaModel) ollamaModel.value = settings.ollama?.model || 'qwen2.5vl:latest';
    if (confidenceThreshold) confidenceThreshold.value = settings.aiAnalysis?.confidenceThreshold || 85;
    if (googleVisionApiKey) googleVisionApiKey.value = settings.googleVision?.apiKey || '';
    
    await loadDatabaseStats();
    
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

async function loadDatabaseStats() {
  try {
    const response = await window.electronAPI.getDatabaseStats();
    
    if (response.success && response.stats) {
      document.getElementById('statImages').textContent = response.stats.images;
      document.getElementById('statDerivatives').textContent = response.stats.derivatives;
      document.getElementById('statClusters').textContent = response.stats.clusters;
      document.getElementById('statAnalyzed').textContent = response.stats.analyzed;
      document.getElementById('statFileSize').textContent = response.fileSize;
    }
  } catch (error) {
    console.error('Failed to load database stats:', error);
  }
}

async function handleSelectDatabase() {
  try {
    const result = await window.electronAPI.selectDatabaseLocation();
    
    if (result.canceled) {
      return;
    }
    
    const response = await window.electronAPI.setDatabasePath(result.path);
    
    if (response.success) {
      const dbPathInput = document.getElementById('dbPath');
      if (dbPathInput) {
        dbPathInput.value = response.dbPath;
      }
      await loadDatabaseStats();
      alert('Database location set successfully!');
    } else {
      alert(`Failed to set database location: ${response.error}`);
    }
    
  } catch (error) {
    console.error('Error setting database location:', error);
    alert(`Error: ${error.message}`);
  }
}

async function handleClearDatabase() {
  const confirmed = confirm(
    '⚠️ WARNING: This will delete ALL records from the database.\n\n' +
    'This action cannot be undone!\n\n' +
    'Are you sure you want to continue?'
  );
  
  if (!confirmed) {
    return;
  }
  
  try {
    const response = await window.electronAPI.clearDatabase();
    
    if (response.success) {
      await loadDatabaseStats();
      alert('Database cleared successfully!');
    } else {
      alert(`Failed to clear database: ${response.error}`);
    }
    
  } catch (error) {
    console.error('Error clearing database:', error);
    alert(`Error: ${error.message}`);
  }
}

async function checkDatabaseOnStartup() {
  try {
    const status = await window.electronAPI.checkDatabaseStatus();
    
    if (status.needsSetup) {
      const setupNow = confirm(
        'Database not found!\n\n' +
        'Please select an existing database or choose a location to create a new one.\n\n' +
        'Click OK to set up database now, or Cancel to set it up later in Settings.'
      );
      
      if (setupNow) {
        const settingsTab = document.querySelector('[data-tab="settings"]');
        if (settingsTab) {
          settingsTab.click();
        }
        
        const selectDbBtn = document.getElementById('selectDbBtn');
        setTimeout(() => {
          if (selectDbBtn) {
            selectDbBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
            selectDbBtn.style.animation = 'pulse 1s ease-in-out 3';
          }
        }, 500);
      }
    }
  } catch (error) {
    console.error('Failed to check database status:', error);
  }
}

// ============================================
// Results Tab - Load Processed Data
// ============================================
let resultsCurrentPage = 1;
let resultsRowsPerPage = 10;
let allProcessedImages = [];

/**
 * Build similarity groups using Union-Find algorithm
 * Groups connected clusters together and picks the best representative
 */
function buildSimilarityGroups(clusters, similarityResults) {
  console.log('🔗 Building similarity groups...');
  console.log('Input clusters:', clusters.length);
  console.log('Similarity pairs:', similarityResults.length);
  
  // Create a map of cluster path to cluster object
  const clusterMap = new Map();
  clusters.forEach(cluster => {
    clusterMap.set(cluster.representativePath, cluster);
  });
  
  // Union-Find data structure
  const parent = new Map();
  const rank = new Map();
  
  // Initialize each cluster as its own parent
  clusters.forEach(cluster => {
    parent.set(cluster.representativePath, cluster.representativePath);
    rank.set(cluster.representativePath, 0);
  });
  
  // Find with path compression
  function find(x) {
    if (parent.get(x) !== x) {
      parent.set(x, find(parent.get(x)));
    }
    return parent.get(x);
  }
  
  // Union by rank
  function union(x, y) {
    const rootX = find(x);
    const rootY = find(y);
    
    if (rootX === rootY) return;
    
    const rankX = rank.get(rootX);
    const rankY = rank.get(rootY);
    
    if (rankX < rankY) {
      parent.set(rootX, rootY);
    } else if (rankX > rankY) {
      parent.set(rootY, rootX);
    } else {
      parent.set(rootY, rootX);
      rank.set(rootX, rankX + 1);
    }
  }
  
  // Union all similar pairs
  similarityResults.forEach(sim => {
    union(sim.rep1, sim.rep2);
  });
  
  // Group clusters by their root parent
  const groups = new Map();
  clusters.forEach(cluster => {
    const root = find(cluster.representativePath);
    if (!groups.has(root)) {
      groups.set(root, []);
    }
    groups.get(root).push(cluster);
  });
  
  console.log(`📦 Created ${groups.size} groups from ${clusters.length} clusters`);
  
  // Build final group objects
  const similarityGroups = [];
  
  groups.forEach((groupClusters, root) => {
    // Count similarity connections for each cluster in this group
    const connectionCounts = new Map();
    
    groupClusters.forEach(cluster => {
      const connections = similarityResults.filter(
        sim => sim.rep1 === cluster.representativePath || sim.rep2 === cluster.representativePath
      );
      connectionCounts.set(cluster.representativePath, connections.length);
    });
    
    // Pick the cluster with the most connections as main representative
    let mainRep = groupClusters[0];
    let maxConnections = connectionCounts.get(mainRep.representativePath) || 0;
    
    groupClusters.forEach(cluster => {
      const count = connectionCounts.get(cluster.representativePath) || 0;
      if (count > maxConnections) {
        maxConnections = count;
        mainRep = cluster;
      }
    });
    
    // Get all similar representatives (others in the group)
    const similarReps = groupClusters
      .filter(c => c.representativePath !== mainRep.representativePath)
      .map(c => {
        // Find the similarity score between mainRep and this cluster
        const simPair = similarityResults.find(
          sim => (sim.rep1 === mainRep.representativePath && sim.rep2 === c.representativePath) ||
                 (sim.rep2 === mainRep.representativePath && sim.rep1 === c.representativePath)
        );
        
        return {
          cluster: c,
          similarityPercent: simPair ? simPair.similarityPercent : 0
        };
      });
    
    // ✅ CRITICAL FIX: Get derivatives from window.processedClusters (source of truth)
    console.log(`🔍 Looking up derivatives for group: ${mainRep.representativeFilename}`);
    
    const mainRepWithDerivatives = window.processedClusters.find(c => 
      c.representativePath === mainRep.representativePath
    );
    
    if (mainRepWithDerivatives?.derivatives) {
      console.log(`   ✅ Found ${mainRepWithDerivatives.derivatives.length} derivatives for main rep`);
    } else {
      console.log(`   ⚠️ No derivatives found for main rep in window.processedClusters`);
    }
    
    const similarRepsWithDerivatives = similarReps.map(sim => {
      const sourceCluster = window.processedClusters.find(c =>
        c.representativePath === sim.cluster.representativePath
      );
      
      if (sourceCluster?.derivatives && sourceCluster.derivatives.length > 0) {
        console.log(`   ✅ Found ${sourceCluster.derivatives.length} derivatives for similar: ${sim.cluster.representativeFilename}`);
      }
      
      return {
        ...sim,
        cluster: {
          ...sim.cluster,
          derivatives: sourceCluster?.derivatives || []
        }
      };
    });
    
    const group = {
      mainRep: {
        ...mainRep,
        derivatives: mainRepWithDerivatives?.derivatives || []
      },
      similarReps: similarRepsWithDerivatives,
      allClusters: groupClusters.map(c => {
        const sourceCluster = window.processedClusters.find(pc =>
          pc.representativePath === c.representativePath
        );
        return {
          ...c,
          derivatives: sourceCluster?.derivatives || []
        };
      }),
      connectionCount: maxConnections
    };
    
    similarityGroups.push(group);
    
    console.log(`  Group: ${mainRep.representativeFilename} (${maxConnections} connections) + ${similarReps.length} similar`);
  });
  
  // Sort groups by connection count (most connected first)
  similarityGroups.sort((a, b) => b.connectionCount - a.connectionCount);
  
  // ============================================================================
  // 🔍 STEP 2: AFTER buildSimilarityGroups - Track derivatives after grouping
  // ============================================================================
  console.log('\n🔍 ========== STEP 2: AFTER buildSimilarityGroups ==========');
  let step2Derivs = 0;
  let step2Files = 0;
  let step2Reps = 0;
  similarityGroups.forEach((group, idx) => {
    const mainDerivs = group.mainRep.derivatives?.length || 0;
    const mainImages = group.mainRep.imagePaths?.length || 0;
    step2Derivs += mainDerivs;
    step2Files += mainImages;
    step2Reps += 1; // main rep
    
    console.log(`[${idx}] ${group.mainRep.representativeFilename}`);
    console.log(`     Main: imagePaths=${mainImages}, derivatives=${mainDerivs}`);
    
    if (group.similarReps) {
      group.similarReps.forEach((sim, simIdx) => {
        const simDerivs = sim.cluster.derivatives?.length || 0;
        const simImages = sim.cluster.imagePaths?.length || 0;
        step2Derivs += simDerivs;
        step2Files += simImages;
        step2Reps += 1;
        console.log(`     Similar ${simIdx + 1}: imagePaths=${simImages}, derivatives=${simDerivs}`);
      });
    }
  });
  console.log(`📊 Total after grouping: ${step2Reps} reps + ${step2Files} images + ${step2Derivs} derivatives`);
  console.log(`📊 GRAND TOTAL: ${step2Reps + step2Files + step2Derivs} files`);
  console.log(`📊 EXPECTED: 78 files`);
  console.log(`📊 DIFFERENCE: ${78 - (step2Reps + step2Files + step2Derivs)} files ${78 - (step2Reps + step2Files + step2Derivs) > 0 ? 'MISSING' : 'EXTRA'}`);
  console.log('🔍 ==========================================\n');
  // ============================================================================
  
  console.log('✅ Similarity groups built successfully');
  
  return similarityGroups;
}

async function loadProcessedResults() {
  try {
    console.log('Loading processed clusters from memory...');
    
    const resultsContent = document.getElementById('resultsContent');
    const resultsTableContainer = document.getElementById('resultsTableContainer');
    
    // Check if we have processed clusters from the last processing run
    if (!window.processedClusters || window.processedClusters.length === 0) {
      resultsContent.innerHTML = `
        <div class="no-results">
          <h3>No Processed Results</h3>
          <p>No images have been processed yet. Scan a directory and process some images to see results here.</p>
          <button onclick="document.querySelector('[data-tab=\\"ingest\\"]').click()" class="select-btn">
            Go to Ingest Tab
          </button>
        </div>
      `;
      resultsContent.style.display = 'block';
      resultsTableContainer.style.display = 'none';
      return;
    }

    // Build similarity groups if we have similarity results
    if (window.similarityResults && window.similarityResults.length > 0) {
      // ============================================================================
      // 🔍 PRE-GROUPING DIAGNOSTIC - Check which clusters are standalone
      // ============================================================================
      console.log('\n🔍 ========== PRE-GROUPING CHECK ==========');
      console.log(`  window.processedClusters: ${window.processedClusters.length} clusters`);
      console.log(`  window.similarityResults: ${window.similarityResults.length} pairs`);
      
      // Extract unique cluster names from similarity pairs
      const clustersInSimilarity = new Set();
      window.similarityResults.forEach(pair => {
        // Try different possible property names for similarity pair structure
        const rep1 = pair.rep1 || pair.image1 || pair.path1;
        const rep2 = pair.rep2 || pair.image2 || pair.path2;
        if (rep1) clustersInSimilarity.add(rep1);
        if (rep2) clustersInSimilarity.add(rep2);
      });
      
      console.log(`  Clusters appearing in similarity results: ${clustersInSimilarity.size}`);
      console.log(`  Standalone clusters (no matches): ${window.processedClusters.length - clustersInSimilarity.size}`);
      
      // List standalone clusters
      const standaloneClusters = window.processedClusters.filter(c => 
        !clustersInSimilarity.has(c.representativePath) && 
        !clustersInSimilarity.has(c.representativeFilename)
      );
      if (standaloneClusters.length > 0) {
        console.log('\n  📦 Standalone clusters that will be MISSED by buildSimilarityGroups:');
        standaloneClusters.forEach(c => {
          console.log(`     - ${c.representativeFilename} (${c.imageCount} images, ${c.derivatives?.length || 0} derivatives)`);
        });
      }
      console.log('🔍 ==========================================\n');
      // ============================================================================
      
      // ============================================================================
      // 🔍 COMPREHENSIVE DIAGNOSTIC - Check window.processedClusters
      // ============================================================================
      console.log('\n🔍 ========== WINDOW.PROCESSEDCLUSTERS DIAGNOSTIC ==========');
      console.log(`Total clusters in window.processedClusters: ${window.processedClusters.length}`);
      
      let totalDerivativesFound = 0;
      window.processedClusters.forEach((cluster, idx) => {
        const derivCount = cluster.derivatives?.length || 0;
        totalDerivativesFound += derivCount;
        
        console.log(`\n[${idx}] ${cluster.representativeFilename || cluster.representative}`);
        console.log(`    representativePath: ${cluster.representativePath}`);
        console.log(`    Has derivatives array: ${!!cluster.derivatives}`);
        console.log(`    Derivatives count: ${derivCount}`);
        
        if (derivCount > 0) {
          console.log(`    Derivatives:`);
          cluster.derivatives.forEach(d => {
            console.log(`      - ${d.split('/').pop()}`);
          });
        }
      });
      
      console.log(`\n📊 TOTAL DERIVATIVES IN WINDOW.PROCESSEDCLUSTERS: ${totalDerivativesFound}`);
      console.log('🔍 ========== END DIAGNOSTIC ==========\n');
      // ============================================================================
      
      console.log('Building similarity groups...');
      const groups = buildSimilarityGroups(window.processedClusters, window.similarityResults);
      
      // ✅ DEDUPLICATE - Remove groups with same mainRep
      const seenPaths = new Set();
      const uniqueGroups = [];
      
      groups.forEach((group, idx) => {
        const repPath = group.mainRep.representativePath;
        if (!seenPaths.has(repPath)) {
          seenPaths.add(repPath);
          uniqueGroups.push(group);
          console.log(`✅ Keep group ${idx}: ${group.mainRep.representativeFilename}`);
        } else {
          console.log(`❌ Skip duplicate group ${idx}: ${group.mainRep.representativeFilename}`);
        }
      });
      
      allProcessedImages = uniqueGroups;
      console.log(`Loaded ${uniqueGroups.length} unique similarity groups (removed ${groups.length - uniqueGroups.length} duplicates)`);
    } else {
      // No similarity results, treat each cluster as its own group
      allProcessedImages = window.processedClusters.map(cluster => ({
        mainRep: cluster,
        similarReps: [],
        allClusters: [cluster],
        connectionCount: 0
      }));
      console.log('Loaded processed clusters (no similarity grouping):', allProcessedImages.length);
    }

    // Hide empty state, show table
    resultsContent.style.display = 'none';
    resultsTableContainer.style.display = 'block';

    // Reset to first page
    resultsCurrentPage = 1;

    // Render table - ✅ ADD AWAIT
    await renderResultsPage();
    setupResultsPaginationControls();
    
    // Similarity summary removed - grouping in table is sufficient

  } catch (error) {
    console.error('Failed to load processed results:', error);
    const resultsContent = document.getElementById('resultsContent');
    if (resultsContent) {
      resultsContent.style.display = 'block';
      document.getElementById('resultsTableContainer').style.display = 'none';
      resultsContent.innerHTML = `
        <div class="error-state">
          <h3>Error Loading Results</h3>
          <p>Failed to load processed results: ${error.message}</p>
          <button onclick="loadProcessedResults()" class="select-btn">
            Try Again
          </button>
        </div>
      `;
    }
  }
}

// Render current page of results
async function renderResultsPage() {
  const tbody = document.getElementById('processedResultsTableBody'); // CHANGED ID
  if (!tbody) {
    console.error('ERROR: processedResultsTableBody not found!');
    return;
  }

  tbody.innerHTML = '';

  const start = (resultsCurrentPage - 1) * resultsRowsPerPage;
  const end = Math.min(start + resultsRowsPerPage, allProcessedImages.length);
  const pageGroups = allProcessedImages.slice(start, end);

  console.log(`Rendering results page ${resultsCurrentPage}: rows ${start + 1} to ${end}`);
  console.log('Groups to render:', pageGroups.length);

  // ✅ FIX: Use Promise.all to wait for all async row creations
  const rows = await Promise.all(
    pageGroups.map(group => createResultsTableRowFromGroup(group))
  );
  
  // Append all rows at once
  rows.forEach(row => {
    tbody.appendChild(row);
  });

  console.log('Rows added to tbody:', tbody.children.length);

  updateResultsPaginationInfo();
}

// Create a table row for a similarity group
async function createResultsTableRowFromGroup(group) {
  console.log('📋 Creating row for group:', {
    mainRep: group.mainRep.representativeFilename,
    similarCount: group.similarReps.length,
    totalClusters: group.allClusters.length
  });

  const cluster = group.mainRep; // Use the main representative for the row
  const row = document.createElement('tr');

  // Column 1: Thumbnail + Parent Image Name (vertical layout)
  const thumbCell = document.createElement('td');
  thumbCell.style.width = '200px';
  thumbCell.style.verticalAlign = 'top';
  
  // Container for thumbnail + info (vertical layout)
  const thumbContainer = document.createElement('div');
  thumbContainer.className = 'parent-thumbnail-container';
  
  // Thumbnail
  const thumbnail = document.createElement('img');
  thumbnail.className = 'parent-thumbnail';
  thumbnail.alt = cluster.representativeFilename;
  thumbnail.title = 'Click to preview';
  
  // Set placeholder first
  thumbnail.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 24 24" fill="none" stroke="%236c757d" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
  
  // Load actual thumbnail
  const thumbPath = cluster.representativePath || cluster.representative;
  loadThumbnail(thumbPath, thumbnail);
  
  // Make thumbnail clickable
  thumbnail.style.cursor = 'pointer';
  thumbnail.onclick = () => {
    showImagePreview(
      cluster.representativePath,
      cluster.representativeFilename
    );
  };
  
  // Info below thumbnail
  const infoDiv = document.createElement('div');
  infoDiv.className = 'parent-info';
  
  // Similar count (if any)
  if (group.similarReps.length > 0) {
    const similarCountDiv = document.createElement('div');
    similarCountDiv.className = 'similar-count';
    similarCountDiv.textContent = `🔗 ${group.similarReps.length} similar cluster${group.similarReps.length > 1 ? 's' : ''}`;
    infoDiv.appendChild(similarCountDiv);
  }
  
  // Filename
  const fileName = document.createElement('div');
  fileName.className = 'parent-filename';
  fileName.textContent = cluster.representativeFilename || cluster.representative || 'Unknown';
  infoDiv.appendChild(fileName);
  
  // Bracketed count
  if (cluster.isBracketed) {
    const countDiv = document.createElement('div');
    countDiv.className = 'parent-count';
    countDiv.textContent = `${cluster.imageCount} bracketed images`;
    infoDiv.appendChild(countDiv);
  }
  
  thumbContainer.appendChild(thumbnail);
  thumbContainer.appendChild(infoDiv);
  thumbCell.appendChild(thumbContainer);

  // Column 2: Similar Parent Representatives (show OTHER clusters in the group)
  const similarCell = document.createElement('td');
  similarCell.className = 'child-images';

  if (group.similarReps.length > 0) {
    const thumbnailGrid = document.createElement('div');
    thumbnailGrid.className = 'similar-thumbnails-grid';
    thumbnailGrid.style.display = 'grid';
      thumbnailGrid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(100px, 1fr))';
      thumbnailGrid.style.gap = '5px'; // ✅ 5px gap
    thumbnailGrid.style.marginBottom = '8px';
    
    // Show thumbnails for all OTHER representatives in the group
    group.similarReps.forEach((simRep) => {
      const thumbContainer = document.createElement('div');
      thumbContainer.style.position = 'relative';
      thumbContainer.style.display = 'flex';
      thumbContainer.style.flexDirection = 'column';
      thumbContainer.style.alignItems = 'center';
      thumbContainer.style.gap = '4px';
      
      // Thumbnail image for OTHER cluster representative
      const thumbnail = document.createElement('img');
      thumbnail.style.objectFit = 'cover';
      thumbnail.style.borderRadius = '4px';
      thumbnail.style.backgroundColor = '#e9ecef';
      thumbnail.style.border = '2px solid #0066cc';
      thumbnail.style.cursor = 'pointer';
      thumbnail.title = `${simRep.cluster.representativeFilename} - ${simRep.similarityPercent}% match`;
      
      // Placeholder
      thumbnail.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="%236c757d" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
      
      // Load actual thumbnail of OTHER representative
      loadThumbnail(simRep.cluster.representativePath, thumbnail);
      
      // Make thumbnail clickable
      thumbnail.onclick = () => {
        showImagePreview(
          simRep.cluster.representativePath,
          simRep.cluster.representativeFilename,
          simRep.similarityPercent,
          cluster  // ← ADD THIS 4th PARAMETER: Pass the parent cluster for extraction
        );
      };
      
      // Filename label
      const label = document.createElement('div');
      label.style.fontSize = '10px';
      label.style.color = '#6c757d';
      label.style.textAlign = 'center';
      label.style.wordBreak = 'break-all';
      label.style.maxWidth = '80px';
      label.textContent = simRep.cluster.representativeFilename;
      
      thumbContainer.appendChild(thumbnail);
      thumbContainer.appendChild(label);
      
      thumbnailGrid.appendChild(thumbContainer);
    });
    
    similarCell.appendChild(thumbnailGrid);
    
  } else {
    similarCell.textContent = '—';
  }

  // Column 3: Keywords (editable with delete buttons + add new)
  const keywordsCell = document.createElement('td');
  keywordsCell.className = 'keywords-cell';

  const keywordsList = document.createElement('div');
  keywordsList.className = 'keywords-list';

  // Display existing keywords
  if (cluster.keywords && cluster.keywords.length > 0) {
    cluster.keywords.forEach(keyword => {
      const keywordItem = document.createElement('div');
      keywordItem.className = 'keyword-item';
      
      // Delete button (X)
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'keyword-delete-btn';
      deleteBtn.textContent = '×';
      deleteBtn.title = 'Remove keyword';
      deleteBtn.onclick = (e) => {
        e.stopPropagation();
        removeKeyword(group.mainRep.representativePath, keyword, keywordItem);
      };
      
      // Editable keyword text
      const keywordText = document.createElement('span');
      keywordText.className = 'keyword-text';
      keywordText.textContent = keyword;
      keywordText.contentEditable = true;
      keywordText.spellcheck = false;
      keywordText.onclick = (e) => {
        e.stopPropagation();
        keywordText.focus();
      };
      keywordText.onblur = () => {
        const newValue = keywordText.textContent.trim();
        if (newValue && newValue !== keyword) {
          updateKeyword(group.mainRep.representativePath, keyword, newValue);
        } else if (!newValue) {
          keywordText.textContent = keyword; // Revert if empty
        }
      };
      keywordText.onkeydown = (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          keywordText.blur();
        }
        if (e.key === 'Escape') {
          keywordText.textContent = keyword; // Revert
          keywordText.blur();
        }
      };
      
      keywordItem.appendChild(deleteBtn);
      keywordItem.appendChild(keywordText);
      keywordsList.appendChild(keywordItem);
    });
  }

  // ✅ NEW: Add keyword input + button
  const addKeywordContainer = document.createElement('div');
  addKeywordContainer.style.display = 'flex';
  addKeywordContainer.style.gap = '4px';
  addKeywordContainer.style.marginTop = '6px';

  const addKeywordInput = document.createElement('input');
  addKeywordInput.type = 'text';
  addKeywordInput.placeholder = 'Add keyword...';
  addKeywordInput.style.flex = '1';
  addKeywordInput.style.padding = '4px 8px';
  addKeywordInput.style.border = '1px solid #dee2e6';
  addKeywordInput.style.borderRadius = '3px';
  addKeywordInput.style.fontSize = '12px';

  const addKeywordBtn = document.createElement('button');
  addKeywordBtn.textContent = '+';
  addKeywordBtn.title = 'Add keyword';
  addKeywordBtn.style.padding = '4px 10px';
  addKeywordBtn.style.backgroundColor = '#28a745';
  addKeywordBtn.style.color = 'white';
  addKeywordBtn.style.border = 'none';
  addKeywordBtn.style.borderRadius = '3px';
  addKeywordBtn.style.cursor = 'pointer';
  addKeywordBtn.style.fontSize = '14px';
  addKeywordBtn.style.fontWeight = 'bold';

  addKeywordBtn.onclick = (e) => {
    e.stopPropagation();
    const newKeyword = addKeywordInput.value.trim();
    if (newKeyword) {
      addKeywordToCluster(group.mainRep.representativePath, newKeyword, keywordsList, addKeywordInput);
    }
  };

  // Also allow Enter key to add keyword
  addKeywordInput.onkeypress = (e) => {
    if (e.key === 'Enter') {
      e.stopPropagation();
      const newKeyword = addKeywordInput.value.trim();
      if (newKeyword) {
        addKeywordToCluster(group.mainRep.representativePath, newKeyword, keywordsList, addKeywordInput);
      }
    }
  };

  addKeywordContainer.appendChild(addKeywordInput);
  addKeywordContainer.appendChild(addKeywordBtn);

  keywordsCell.appendChild(keywordsList);
  keywordsCell.appendChild(addKeywordContainer);

  // Column 4: GPS Coordinates
  const gpsCell = document.createElement('td');
  gpsCell.className = 'gps-cell';

  // Check if any image in the group has GPS data
  const hasGPS = cluster.gps || group.similarReps?.some(sim => sim.cluster.gps);

  if (hasGPS) {
    const gpsValue = cluster.gps || group.similarReps.find(sim => sim.cluster.gps)?.cluster.gps;
    
    const gpsDisplay = document.createElement('div');
    gpsDisplay.className = 'gps-display';
    gpsDisplay.textContent = `${gpsValue.latitude}, ${gpsValue.longitude}`;
    gpsDisplay.title = 'Click to edit GPS coordinates';
    // Store cluster path for later forced-save
    gpsDisplay.dataset.clusterPath = group.mainRep.representativePath;
    gpsCell.appendChild(gpsDisplay);
    
    // Make editable
    gpsDisplay.contentEditable = true;
    gpsDisplay.spellcheck = false;
    gpsDisplay.onclick = (e) => {
      e.stopPropagation();
      gpsDisplay.focus();
    };
    gpsDisplay.onblur = () => {
      updateGPS(group.mainRep.representativePath, gpsDisplay.textContent.trim());
    };
    gpsDisplay.onkeydown = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        gpsDisplay.blur();
      }
      if (e.key === 'Escape') {
        gpsDisplay.textContent = `${gpsValue.latitude}, ${gpsValue.longitude}`;
        gpsDisplay.blur();
      }
    };
  } else {
    // No GPS - show "no gps" text that disappears on click
    const gpsInput = document.createElement('input');
    gpsInput.type = 'text';
    gpsInput.className = 'gps-input gps-input-empty';
    gpsInput.value = 'no gps';
    gpsInput.title = 'Click to enter GPS coordinates (latitude, longitude)';
    // Store cluster path for later forced-save
    gpsInput.dataset.clusterPath = group.mainRep.representativePath;
    
    // Clear text on focus
    gpsInput.onfocus = () => {
      if (gpsInput.value === 'no gps') {
        gpsInput.value = '';
        gpsInput.classList.remove('gps-input-empty');
      }
    };
    
    // Restore "no gps" if empty on blur
    gpsInput.onblur = () => {
      const trimmed = gpsInput.value.trim();
      if (trimmed && trimmed !== 'no gps') {
        updateGPS(group.mainRep.representativePath, trimmed);
        // Replace input with display after successful update
        const gpsDisplay = document.createElement('div');
        gpsDisplay.className = 'gps-display';
        gpsDisplay.textContent = trimmed;
        gpsDisplay.dataset.clusterPath = group.mainRep.representativePath;
        gpsDisplay.contentEditable = true;
        gpsDisplay.spellcheck = false;
        gpsDisplay.onclick = (e) => {
          e.stopPropagation();
          gpsDisplay.focus();
        };
        gpsDisplay.onblur = () => {
          updateGPS(group.mainRep.representativePath, gpsDisplay.textContent.trim());
        };
        gpsCell.innerHTML = '';
        gpsCell.appendChild(gpsDisplay);
      } else {
        // Restore "no gps" if empty
        gpsInput.value = 'no gps';
        gpsInput.classList.add('gps-input-empty');
      }
    };
    
    gpsInput.onkeydown = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        gpsInput.blur();
      }
      if (e.key === 'Escape') {
        gpsInput.value = 'no gps';
        gpsInput.classList.add('gps-input-empty');
        gpsInput.blur();
      }
    };
    
    gpsCell.appendChild(gpsInput);
  }

  // Add similarity group indicator
  if (group.similarReps.length > 0) {
    row.title = `Similarity group with ${group.similarReps.length} other cluster(s)`;
    row.style.borderLeft = '4px solid #0066cc';
  }

  // Append all cells
  row.appendChild(thumbCell);
  row.appendChild(similarCell);
  row.appendChild(keywordsCell);
  row.appendChild(gpsCell);

  return row;
}

/**
 * Remove a keyword from a cluster
 */
function removeKeyword(clusterPath, keyword, keywordElement) {
  console.log('🗑️ Removing keyword:', { cluster: clusterPath, keyword });
  
  // Find the cluster in allProcessedImages (the actual display data)
  const group = allProcessedImages.find(g => 
    g.mainRep && g.mainRep.representativePath === clusterPath
  );
  
  if (group && group.mainRep && group.mainRep.keywords) {
    // Remove keyword from array
    group.mainRep.keywords = group.mainRep.keywords.filter(kw => kw !== keyword);
    
    // Also update in window.processedClusters if it exists
    if (window.processedClusters) {
      const windowCluster = window.processedClusters.find(c => 
        c.representativePath === clusterPath
      );
      if (windowCluster && windowCluster.keywords) {
        windowCluster.keywords = windowCluster.keywords.filter(kw => kw !== keyword);
      }
    }
    
    // Remove from DOM
    keywordElement.remove();
    
    console.log('✅ Keyword removed successfully');
  } else {
    console.error('❌ Could not find cluster to remove keyword from');
  }
}

/**
 * Add a keyword to a cluster
 */
function addKeywordToCluster(clusterPath, keyword, keywordsList, inputElement) {
  console.log('➕ Adding keyword:', { cluster: clusterPath, keyword });
  
  // Find the cluster in allProcessedImages
  const group = allProcessedImages.find(g => 
    g.mainRep && g.mainRep.representativePath === clusterPath
  );
  
  if (group && group.mainRep) {
    // Initialize keywords array if it doesn't exist
    if (!group.mainRep.keywords) {
      group.mainRep.keywords = [];
    }
    
    // Check if keyword already exists
    if (group.mainRep.keywords.includes(keyword)) {
      alert('Keyword already exists!');
      inputElement.value = '';
      return;
    }
    
    // Add keyword to array
    group.mainRep.keywords.push(keyword);
    
    // Also update in window.processedClusters if it exists
    if (window.processedClusters) {
      const windowCluster = window.processedClusters.find(c => 
        c.representativePath === clusterPath
      );
      if (windowCluster) {
        if (!windowCluster.keywords) {
          windowCluster.keywords = [];
        }
        if (!windowCluster.keywords.includes(keyword)) {
          windowCluster.keywords.push(keyword);
        }
      }
    }
    
    // Add to DOM (before the add input container)
    const keywordItem = document.createElement('div');
    keywordItem.className = 'keyword-item';
    
    // Delete button (X)
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'keyword-delete-btn';
    deleteBtn.textContent = '×';
    deleteBtn.title = 'Remove keyword';
    deleteBtn.onclick = (e) => {
      e.stopPropagation();
      removeKeyword(clusterPath, keyword, keywordItem);
    };
    
    // Editable keyword text
    const keywordText = document.createElement('span');
    keywordText.className = 'keyword-text';
    keywordText.contentEditable = true;
    keywordText.textContent = keyword;
    keywordText.spellcheck = false;
    keywordText.onclick = (e) => {
      e.stopPropagation();
      keywordText.focus();
    };
    keywordText.onblur = () => {
      const newKeyword = keywordText.textContent.trim();
      if (newKeyword && newKeyword !== keyword) {
        updateKeyword(clusterPath, keyword, newKeyword);
      } else if (!newKeyword) {
        keywordText.textContent = keyword;
      }
    };
    keywordText.onkeydown = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        keywordText.blur();
      }
      if (e.key === 'Escape') {
        keywordText.textContent = keyword;
        keywordText.blur();
      }
    };
    
    keywordItem.appendChild(deleteBtn);
    keywordItem.appendChild(keywordText);
    keywordsList.appendChild(keywordItem);
    
    // Clear input
    inputElement.value = '';
    
    console.log('✅ Keyword added successfully');
  } else {
    console.error('❌ Could not find cluster to add keyword to');
  }
}

/**
 * Update a keyword in a cluster
 */
function updateKeyword(clusterPath, oldKeyword, newKeyword) {
  // Find the cluster in processedClusters
  const cluster = window.processedClusters.find(c => c.mainRep && c.mainRep.representativePath === clusterPath);
  
  if (cluster && cluster.mainRep && cluster.mainRep.keywords) {
    // Update keyword in array
    const index = cluster.mainRep.keywords.indexOf(oldKeyword);
    if (index !== -1) {
      cluster.mainRep.keywords[index] = newKeyword;
      console.log('Keyword updated:', { 
        cluster: cluster.mainRep.representativeFilename, 
        old: oldKeyword, 
        new: newKeyword 
      });
    }
  }
}

/**
 * Update GPS coordinates for a cluster
 * ✅ FIXED: Handles BOTH window.processedClusters (flat array) AND allProcessedImages (nested) structures
 */
function updateGPS(clusterPath, gpsString) {
  console.log('💾 === UPDATE GPS CALLED ===');
  console.log('   Path:', clusterPath);
  console.log('   GPS String:', gpsString);
  
  // Parse GPS string (format: "lat, lon")
  const parts = gpsString.split(',').map(s => s.trim());
  
  if (parts.length !== 2) {
    alert('Invalid GPS format. Use: latitude, longitude (e.g., 51.3887624, 30.1038694)');
    return false;
  }
  
  const latitude = parseFloat(parts[0]);
  const longitude = parseFloat(parts[1]);
  
  if (isNaN(latitude) || isNaN(longitude)) {
    alert('Invalid GPS coordinates. Must be numbers.');
    return false;
  }
  
  if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
    alert('GPS coordinates out of range.\nLatitude: -90 to 90\nLongitude: -180 to 180');
    return false;
  }
  
  const gpsData = { 
    latitude, 
    longitude, 
    source: 'Manual Entry' 
  };
  
  let saved = false;
  
  // ✅ FIX 1: Save to window.processedClusters (flat array - NO mainRep!)
  if (window.processedClusters) {
    console.log('   🔍 Searching window.processedClusters (count:', window.processedClusters.length, ')');
    
    const cluster = window.processedClusters.find(c => 
      c.representativePath === clusterPath || 
      c.representative === clusterPath
    );
    
    if (cluster) {
      cluster.gps = gpsData;
      saved = true;
      console.log('   ✅ GPS saved to window.processedClusters');
      console.log('      Cluster:', cluster.representativeFilename || cluster.representative);
      console.log('      GPS:', gpsData);
    } else {
      console.log('   ⚠️  Cluster NOT found in window.processedClusters');
      console.log('      Looking for path:', clusterPath);
    }
  }
  
  // ✅ FIX 2: ALSO save to allProcessedImages (similarity groups - HAS mainRep)
  if (allProcessedImages) {
    console.log('   🔍 Searching allProcessedImages (count:', allProcessedImages.length, ')');
    
    const group = allProcessedImages.find(g => 
      g.mainRep?.representativePath === clusterPath
    );
    
    if (group) {
      group.mainRep.gps = gpsData;
      saved = true;
      console.log('   ✅ GPS saved to allProcessedImages');
      console.log('      Group:', group.mainRep.representativeFilename);
      console.log('      GPS:', gpsData);
    } else {
      console.log('   ⚠️  Group NOT found in allProcessedImages');
    }
  }
  
  if (saved) {
    console.log('   ✅ GPS UPDATE COMPLETE');
    return true;
  } else {
    console.error('   ❌ GPS NOT SAVED - Cluster not found in any array!');
    return false;
  }
}

// Create a table row for a processed cluster (OLD - kept for compatibility)
async function createResultsTableRow(cluster) {
  // ✅ ADD: Debug what we're receiving
  console.log('📋 Creating row for cluster:', {
    representative: cluster.representative,
    representativePath: cluster.representativePath,
    representativeFilename: cluster.representativeFilename,
    imagePaths: cluster.imagePaths,
    isBracketed: cluster.isBracketed,
    imageCount: cluster.imageCount
  });

  const row = document.createElement('tr');

  // Column 1: Thumbnail + Parent Image Name
  const thumbCell = document.createElement('td');
  thumbCell.style.width = '200px';
  
  const thumbContainer = document.createElement('div');
  thumbContainer.style.display = 'flex';
  thumbContainer.style.alignItems = 'center';
  thumbContainer.style.gap = '12px';
  
  // Thumbnail
  const thumbnail = document.createElement('img');
  thumbnail.style.width = '60px';
  thumbnail.style.height = '60px';
  thumbnail.style.objectFit = 'cover';
  thumbnail.style.borderRadius = '4px';
  thumbnail.style.flexShrink = '0';
  thumbnail.style.backgroundColor = '#e9ecef';
  thumbnail.title = 'Loading...';
  
  // Set placeholder first
  thumbnail.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="%236c757d" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
  
  // Load actual thumbnail asynchronously
  // ✅ ADD: Fallback if representativePath is undefined
  const thumbPath = cluster.representativePath || cluster.representative;
  console.log('🎯 Using thumbnail path:', thumbPath);
  console.log('🎯 Full cluster object:', JSON.stringify(cluster, null, 2)); // ADD THIS LINE
  loadThumbnail(thumbPath, thumbnail);
  
  // Image name
  const nameDiv = document.createElement('div');
  nameDiv.style.flex = '1';
  
  const fileName = document.createElement('div');
  fileName.className = 'parent-image';
  fileName.textContent = cluster.representativeFilename || cluster.representative || 'Unknown';
  
  const countDiv = document.createElement('div');
  countDiv.className = 'parent-count';
  if (cluster.isBracketed) {
    countDiv.textContent = `${cluster.imageCount} bracketed images`;
  }
  
  nameDiv.appendChild(fileName);
  if (cluster.isBracketed) {
    nameDiv.appendChild(countDiv);
  }
  
  thumbContainer.appendChild(thumbnail);
  thumbContainer.appendChild(nameDiv);
  thumbCell.appendChild(thumbContainer);

  // Column 2: Similar Parent Representatives
  const similarCell = document.createElement('td');
  similarCell.className = 'child-images';

  // Find OTHER parent representatives that are visually similar to THIS parent
  console.log('🔍 ===== FINDING SIMILAR FOR CLUSTER =====');
  console.log('📂 Current cluster rep:', cluster.representativePath);
  console.log('📊 Available similarityResults:', window.similarityResults?.length || 0);
  const similarReps = findSimilarForCluster(cluster.representativePath, window.similarityResults || []);
  console.log('✅ Found', similarReps.length, 'similar representatives');
  if (similarReps.length > 0) {
    console.log('📋 Similar reps:', similarReps.map(s => s.otherFileName));
  }
  console.log('🔍 ======================================\n');

  if (similarReps.length > 0) {
    const thumbnailGrid = document.createElement('div');
    thumbnailGrid.className = 'similar-thumbnails-grid';
    thumbnailGrid.style.display = 'grid';
      thumbnailGrid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(100px, 1fr))';
      thumbnailGrid.style.gap = '5px'; // ✅ 5px gap
    thumbnailGrid.style.marginBottom = '8px';
    
    similarReps.forEach((sim) => {
      const thumbContainer = document.createElement('div');
      thumbContainer.style.position = 'relative';
      thumbContainer.style.display = 'flex';
      thumbContainer.style.flexDirection = 'column';
      thumbContainer.style.alignItems = 'center';
      thumbContainer.style.gap = '4px';
      
      // Thumbnail image for OTHER cluster representative
      const thumbnail = document.createElement('img');
      thumbnail.style.objectFit = 'cover';
      thumbnail.style.borderRadius = '4px';
      thumbnail.style.backgroundColor = '#e9ecef';
      thumbnail.style.border = '2px solid #0066cc';
      thumbnail.style.cursor = 'pointer';
      thumbnail.title = `${sim.otherFileName} - ${sim.similarityPercent}% match`;
      
      // Placeholder
      thumbnail.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="%236c757d" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
      
      // Load actual thumbnail of OTHER representative
      loadThumbnail(sim.otherRep, thumbnail);
      
      // Filename label
      const label = document.createElement('div');
      label.style.fontSize = '10px';
      label.style.color = '#6c757d';
      label.style.textAlign = 'center';
      label.style.wordBreak = 'break-all';
      label.style.maxWidth = '80px';
      label.textContent = sim.otherFileName;
      
      // Similarity score badge
      const scoreBadge = document.createElement('span');
      scoreBadge.textContent = `${sim.similarityPercent}%`;
      scoreBadge.style.fontSize = '9px';
      scoreBadge.style.fontWeight = 'bold';
      scoreBadge.style.color = 'white';
      scoreBadge.style.backgroundColor = sim.similarityPercent >= 95 ? '#28a745' : '#ffc107';
      scoreBadge.style.padding = '2px 6px';
      scoreBadge.style.borderRadius = '3px';
      scoreBadge.style.marginTop = '2px';
      scoreBadge.style.display = 'inline-block';
        
        thumbContainer.appendChild(thumbnail);
        thumbContainer.appendChild(label);
      thumbContainer.appendChild(scoreBadge);
      
      thumbnailGrid.appendChild(thumbContainer);
    });
    
    similarCell.appendChild(thumbnailGrid);
    
  } else {
    similarCell.textContent = '—';
  }

  // Column 3: Keywords (unchanged)
  const keywordsCell = document.createElement('td');
  keywordsCell.className = 'child-images';
  
  if (cluster.keywords && cluster.keywords.length > 0) {
    const displayKeywords = cluster.keywords.slice(0, 5);
    
    displayKeywords.forEach(keyword => {
      const badge = document.createElement('span');
      badge.className = 'child-image-item';
      badge.textContent = keyword;
      keywordsCell.appendChild(badge);
    });
    
    if (cluster.keywords.length > 5) {
      const moreBadge = document.createElement('span');
      moreBadge.className = 'child-image-item';
      moreBadge.style.backgroundColor = '#f1f3f5';
      moreBadge.textContent = `+${cluster.keywords.length - 5} more`;
      keywordsCell.appendChild(moreBadge);
    }
  } else {
    keywordsCell.textContent = '—';
  }

  // Column 4: Status (unchanged)
  const statusCell = document.createElement('td');
  const statusBadge = document.createElement('span');
  statusBadge.className = 'status-badge';
  
  if (cluster.analysisCount > 0) {
    statusBadge.classList.add('status-complete');
    statusBadge.textContent = `✓ ${cluster.analysisCount} analysis`;
  } else if (cluster.processed) {
    statusBadge.classList.add('status-ready');
    statusBadge.textContent = 'Metadata extracted';
  } else {
    statusBadge.classList.add('status-pending');
    statusBadge.textContent = 'Pending';
  }
  
  statusCell.appendChild(statusBadge);

  // NEW: Add similarity information if available
  if (window.similarityResults && window.similarityResults.length > 0) {
    const similarReps = findSimilarForCluster(cluster.representativePath, window.similarityResults);
    if (similarReps.length > 0) {
      // Add similarity info to the row title
      row.title = `Similar to: ${similarReps.map(s => s.otherFileName).join(', ')}`;
      row.style.borderLeft = '4px solid #0066cc';
    }
  }

  // Append all cells
  row.appendChild(thumbCell);
  row.appendChild(similarCell);
  row.appendChild(keywordsCell);
  row.appendChild(statusCell);

  return row;
}

// Helper function to load thumbnails asynchronously
async function loadThumbnail(imagePath, imgElement) {
  // ✅ ADD: Debug logging
  console.log('🖼️ Loading thumbnail for:', imagePath);
  
  try {
    // ✅ ADD: Validate input
    if (!imagePath) {
      console.error('❌ loadThumbnail called with empty imagePath!');
      imgElement.title = 'No path provided';
      return;
    }

    const result = await window.electronAPI.getPreviewImage(imagePath);
    
    console.log('📥 Thumbnail result:', { 
      path: imagePath, 
      success: result.success,
      hasDataUrl: !!result.dataUrl,
      error: result.error
    });
    
    if (result.success) {
      imgElement.src = result.dataUrl;
      imgElement.title = imagePath.split('/').pop();
      console.log('✅ Thumbnail loaded successfully:', imagePath.split('/').pop());
    } else {
      // Keep placeholder on error
      imgElement.title = 'Preview not available: ' + (result.error || 'Unknown error');
      console.warn('⚠️ Failed to load thumbnail:', imagePath, result.error);
    }
  } catch (error) {
    console.error('❌ Error loading thumbnail:', error);
    console.error('   Path was:', imagePath);
    imgElement.title = 'Error loading preview: ' + error.message;
  }
}

// Update pagination info display
function updateResultsPaginationInfo() {
  const start = (resultsCurrentPage - 1) * resultsRowsPerPage + 1;
  const end = Math.min(resultsCurrentPage * resultsRowsPerPage, allProcessedImages.length);
  const total = allProcessedImages.length;
  const info = `Showing ${start}-${end} of ${total}`;

  document.getElementById('resultsPageInfoTop').textContent = info;
  document.getElementById('resultsPageInfoBottom').textContent = info;

  const totalPages = Math.ceil(total / resultsRowsPerPage);

  // Enable/disable buttons
  ['Top', 'Bottom'].forEach(suffix => {
    document.getElementById(`resultsFirstPage${suffix}`).disabled = resultsCurrentPage === 1;
    document.getElementById(`resultsPrevPage${suffix}`).disabled = resultsCurrentPage === 1;
    document.getElementById(`resultsNextPage${suffix}`).disabled = resultsCurrentPage === totalPages;
    document.getElementById(`resultsLastPage${suffix}`).disabled = resultsCurrentPage === totalPages;
  });
}

// Setup pagination button handlers
function setupResultsPaginationControls() {
  ['Top', 'Bottom'].forEach(suffix => {
    document.getElementById(`resultsFirstPage${suffix}`).onclick = async () => {
      resultsCurrentPage = 1;
      await renderResultsPage();
    };

    document.getElementById(`resultsPrevPage${suffix}`).onclick = async () => {
      if (resultsCurrentPage > 1) {
        resultsCurrentPage--;
        await renderResultsPage();
      }
    };

    document.getElementById(`resultsNextPage${suffix}`).onclick = async () => {
      const totalPages = Math.ceil(allProcessedImages.length / resultsRowsPerPage);
      if (resultsCurrentPage < totalPages) {
        resultsCurrentPage++;
        await renderResultsPage();
      }
    };

    document.getElementById(`resultsLastPage${suffix}`).onclick = async () => {
      resultsCurrentPage = Math.ceil(allProcessedImages.length / resultsRowsPerPage);
      await renderResultsPage();
    };
  });
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
}

// ============================================
// Similarity Detection Functions
// ============================================

// Store merged clusters
let mergedClusters = new Map(); // Maps original cluster IDs to merged group ID

// Helper function to find similar representatives for a cluster
function findSimilarForCluster(clusterRep, similarityResults) {
  return similarityResults.filter(
    sim => sim.rep1 === clusterRep || sim.rep2 === clusterRep
  ).map(sim => ({
    ...sim,
    otherRep: sim.rep1 === clusterRep ? sim.rep2 : sim.rep1,
    otherFileName: sim.rep1 === clusterRep ? sim.fileName2 : sim.fileName1
  }));
}

// Helper: Get CSS class for similarity score
function getScoreClass(percent) {
  if (percent >= 95) return 'high';
  if (percent >= 90) return 'medium';
  return '';
}

// Helper: Get filename from path
function getFileName(path) {
  return path ? path.split('/').pop() : '';
}

// Helper: Get thumbnail path (placeholder for now)
function getThumbnailPath(imagePath) {
  // This should use the existing thumbnail loading system
  return 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="%236c757d" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
}

// Render similarity section for a cluster
function renderSimilaritySection(similarReps, currentRep) {
  if (!similarReps || similarReps.length === 0) {
    return ''; // Don't show section if no similar representatives
  }

  return `
    <div class="similarity-section">
      <h4>⚡ Similar Representatives Detected (${similarReps.length})</h4>
      <p style="font-size: 12px; color: #6c757d; margin: 5px 0;">
        This cluster's representative is visually similar to:
      </p>
      
      <div class="similar-reps-grid">
        ${similarReps.map(sim => `
          <div class="similar-rep-card" 
               onclick="jumpToCluster('${sim.otherRep}')"
               title="Click to view this cluster">
            <img src="${getThumbnailPath(sim.otherRep)}" 
                 class="similar-rep-thumbnail"
                 alt="${sim.otherFileName}">
            <div class="similar-rep-info">
              <p class="similar-rep-name">${sim.otherFileName}</p>
              <p class="similarity-score ${getScoreClass(sim.similarityPercent)}">
                ${sim.similarityPercent}% match
              </p>
            </div>
          </div>
        `).join('')}
      </div>

      <button class="merge-btn" onclick="mergeClusters('${currentRep}', ${JSON.stringify(similarReps.map(s => s.otherRep))})">
        🔗 Merge Similar Clusters
      </button>
    </div>
  `;
}

// Helper: Jump to another cluster's card
function jumpToCluster(repPath) {
  const cards = document.querySelectorAll('.cluster-card');
  for (const card of cards) {
    const img = card.querySelector('.representative-thumb');
    if (img && img.src.includes(getFileName(repPath))) {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      card.style.animation = 'highlight 1s';
      setTimeout(() => card.style.animation = '', 1000);
      break;
    }
  }
}

// Merge clusters functionality
async function mergeClusters(mainRep, similarReps) {
  console.log('Merging clusters:', mainRep, similarReps);
  
  // Find all cluster cards to merge
  const mainCard = findClusterCardByRep(mainRep);
  const similarCards = similarReps.map(rep => findClusterCardByRep(rep));
  
  if (!mainCard || similarCards.some(c => !c)) {
    console.error('Could not find all clusters to merge');
    return;
  }
  
  // Create merged cluster
  const mergedData = {
    id: `merged_${Date.now()}`,
    mainRepresentative: mainRep,
    subRepresentatives: similarReps,
    allMembers: [], // Collect all members
    merged: true
  };
  
  // Collect members from all clusters
  const allClusters = [mainCard, ...similarCards];
  allClusters.forEach(card => {
    const membersDiv = card.querySelector('.members-section');
    if (membersDiv) {
      const members = Array.from(membersDiv.querySelectorAll('.member-item'))
        .map(item => item.dataset.path);
      mergedData.allMembers.push(...members);
    }
  });
  
  // Store merge info
  mergedClusters.set(mergedData.id, mergedData);
  
  // UI: Update main card to show merged state
  mainCard.classList.add('merged-cluster');
  mainCard.querySelector('.cluster-header h3').textContent += ' (Merged)';
  
  // Update member count
  mainCard.querySelector('.image-count').textContent = `${mergedData.allMembers.length} images (merged)`;
  
  // Hide similar clusters
  similarCards.forEach(card => {
    card.style.display = 'none';
    card.dataset.mergedInto = mergedData.id;
  });
  
  // Add unmerge button
  const mergeBtn = mainCard.querySelector('.merge-btn');
  if (mergeBtn) {
    mergeBtn.textContent = '↩️ Unmerge Clusters';
    mergeBtn.onclick = () => unmergeClusters(mergedData.id);
  }
  
  // Show success message
  showNotification(`Merged ${allClusters.length} clusters successfully`);
}

// Unmerge clusters functionality
function unmergeClusters(mergedId) {
  const mergedData = mergedClusters.get(mergedId);
  if (!mergedData) return;
  
  // Show hidden clusters again
  const hiddenCards = document.querySelectorAll(`[data-merged-into="${mergedId}"]`);
  hiddenCards.forEach(card => {
    card.style.display = '';
    delete card.dataset.mergedInto;
  });
  
  // Reset main card
  const mainCard = findClusterCardByRep(mergedData.mainRepresentative);
  if (mainCard) {
    mainCard.classList.remove('merged-cluster');
    mainCard.querySelector('.cluster-header h3').textContent = 
      mainCard.querySelector('.cluster-header h3').textContent.replace(' (Merged)', '');
  }
  
  // Remove merge data
  mergedClusters.delete(mergedId);
  
  showNotification('Clusters unmerged');
}

// Find cluster card by representative path
function findClusterCardByRep(repPath) {
  const cards = document.querySelectorAll('.cluster-card');
  for (const card of cards) {
    const img = card.querySelector('.representative-thumb');
    if (img && img.src.includes(getFileName(repPath))) {
      return card;
    }
  }
  return null;
}

// Show notification
function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    background: #28a745;
    color: white;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    z-index: 10000;
    animation: slideIn 0.3s;
  `;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// Render similarity summary section - DISABLED (grouping in table is clearer)
// function renderSimilaritySummary() {
//   const resultsTableContainer = document.getElementById('resultsTableContainer');
//   
//   // Check if similarity summary already exists
//   if (document.getElementById('similaritySummary')) {
//     return;
//   }
//   
//   const summaryDiv = document.createElement('div');
//   summaryDiv.id = 'similaritySummary';
//   summaryDiv.className = 'similarity-section';
//   summaryDiv.style.marginBottom = '20px';
//   
//   summaryDiv.innerHTML = `
//     <h4>🔍 Visual Similarity Analysis Complete</h4>
//     <p style="font-size: 14px; color: #6c757d; margin: 10px 0;">
//       Found ${window.similarityResults.length} similar representative pairs.
//       Rows with blue left border indicate clusters with similar representatives.
//       Hover over rows to see similarity details.
//     </p>
//     <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 10px;">
//       ${window.similarityResults.map(sim => `
//         <div style="padding: 8px 12px; background: white; border: 1px solid #dee2e6; border-radius: 6px; font-size: 13px;">
//           <strong>${sim.fileName1}</strong> ↔ <strong>${sim.fileName2}</strong><br>
//           <span style="color: ${sim.similarityPercent >= 95 ? '#28a745' : sim.similarityPercent >= 90 ? '#ffc107' : '#0066cc'}; font-weight: bold;">
//             ${sim.similarityPercent}% match
//           </span>
//         </div>
//       `).join('')}
//     </div>
//   `;
//   
//   // Insert before the table
//   resultsTableContainer.insertBefore(summaryDiv, resultsTableContainer.firstChild);
// }

// ============================================
// Image Preview Modal
// ============================================

/**
 * Show image preview modal
 */
/**
 * Show image preview modal with optional "Make Parent Image" button
 */
async function showImagePreview(imagePath, filename, similarityPercent = null, sourceCluster = null) {
  const modal = document.getElementById('imagePreviewModal');
  const previewImg = document.getElementById('previewImage');
  const filenameEl = document.getElementById('previewFilename');
  const similarityEl = document.getElementById('previewSimilarity');
  const makeParentBtn = document.getElementById('makeParentImageBtn');
  
  // Load thumbnail
  const result = await window.electronAPI.getPreviewImage(imagePath);
  
  if (result.success) {
    previewImg.src = result.dataUrl;
    filenameEl.textContent = filename;
    
    // Show similarity percentage if available
    if (similarityPercent) {
      similarityEl.textContent = `${similarityPercent}% match`;
      similarityEl.style.display = 'block';
    } else {
      similarityEl.style.display = 'none';
    }
    
    // Show "Make Parent Image" button only for Similar Parent Representatives
    if (sourceCluster && similarityPercent) {
      makeParentBtn.style.display = 'block';
      
      // Store data on the button for the click handler
      makeParentBtn.dataset.imagePath = imagePath;
      makeParentBtn.dataset.filename = filename;
      makeParentBtn.dataset.sourceClusterPath = sourceCluster.representativePath;
    } else {
      makeParentBtn.style.display = 'none';
    }
    
    modal.style.display = 'flex';
  } else {
    console.error('Failed to load preview:', result.error);
    alert('Failed to load image preview');
  }
}

/**
 * Close image preview modal
 */
function closeImagePreview() {
  console.log('🔴 closeImagePreview called');
  const modal = document.getElementById('imagePreviewModal');
  if (modal) {
    modal.style.display = 'none';
    console.log('✅ Modal closed');
  } else {
    console.error('❌ Modal element not found');
  }
}

/**
 * Extract a Similar Parent Representative and make it its own parent image
 */
function makeParentImage(imagePath, sourceClusterPath) {
  console.log('🔄 Extracting image to new parent cluster:', imagePath);
  console.log('   From source cluster:', sourceClusterPath);
  
  // Find the source super cluster in allProcessedImages
  const sourceGroupIndex = allProcessedImages.findIndex(g => 
    g.mainRep && g.mainRep.representativePath === sourceClusterPath
  );
  
  if (sourceGroupIndex === -1) {
    console.error('❌ Source cluster not found');
    alert('Error: Could not find source cluster');
    return;
  }
  
  const sourceGroup = allProcessedImages[sourceGroupIndex];
  
  // Find the specific similar rep to extract
  const simRepIndex = sourceGroup.similarReps.findIndex(
    sim => sim.cluster.representativePath === imagePath
  );
  
  if (simRepIndex === -1) {
    console.error('❌ Similar representative not found in source cluster');
    alert('Error: Could not find image in cluster');
    return;
  }
  
  // Extract the similar rep's cluster data
  const extractedCluster = sourceGroup.similarReps[simRepIndex].cluster;
  
  // Remove it from the source group's similarReps
  sourceGroup.similarReps.splice(simRepIndex, 1);
  
  // Also remove from allClusters array if it exists
  const allClustersIndex = sourceGroup.allClusters.findIndex(
    c => c.representativePath === imagePath
  );
  if (allClustersIndex !== -1) {
    sourceGroup.allClusters.splice(allClustersIndex, 1);
  }
  
  // Update connection count for source group
  sourceGroup.connectionCount = sourceGroup.similarReps.length;
  
  // Create a new group with just this image as the parent
  const newGroup = {
    mainRep: extractedCluster,
    similarReps: [],
    allClusters: [extractedCluster],
    connectionCount: 0
  };
  
  // Add the new group to allProcessedImages
  allProcessedImages.push(newGroup);
  
  // Also update window.processedClusters if it exists
  if (window.processedClusters) {
    const existingIndex = window.processedClusters.findIndex(
      c => c.representativePath === imagePath
    );
    if (existingIndex === -1) {
      window.processedClusters.push(extractedCluster);
    }
  }
  
  // Also add to allClustersForAnalysis if it exists (for AI Analysis tab)
  if (window.allClustersForAnalysis) {
    const analysisExists = window.allClustersForAnalysis.findIndex(
      g => g.mainRep && g.mainRep.representativePath === imagePath
    );
    if (analysisExists === -1) {
      window.allClustersForAnalysis.push(newGroup);
    }
  }
  
  console.log('✅ Created new parent cluster:', extractedCluster.representativeFilename);
  console.log('   Total clusters now:', allProcessedImages.length);
  console.log('   Source cluster now has', sourceGroup.similarReps.length, 'similar reps');
  
  // Close the modal
  closeImagePreview();
  
  // Refresh the Visual Analysis table to show the changes
  refreshVisualAnalysisTable();
  
  // Show success notification
  showNotification(`Created new parent cluster: ${extractedCluster.representativeFilename}`);
}

/**
 * Refresh the Visual Analysis table after making changes
 */
async function refreshVisualAnalysisTable() {
  console.log('🔄 Refreshing Visual Analysis table...');
  
  // Re-render the current page
  await renderResultsPage();
  
  console.log('✅ Visual Analysis table refreshed');
}

/**
 * Initialize modal event listeners
 */
function initializeModalListeners() {
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalBackdrop = document.getElementById('modalBackdrop');
  const makeParentBtn = document.getElementById('makeParentImageBtn');
  
  if (modalCloseBtn) {
    modalCloseBtn.addEventListener('click', (e) => {
      console.log('🔴 Close button clicked');
      e.stopPropagation();
      closeImagePreview();
    });
    console.log('✅ Modal close button listener attached');
  } else {
    console.error('❌ modalCloseBtn not found');
  }
  
  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', (e) => {
      console.log('🔴 Backdrop clicked');
      if (e.target === modalBackdrop) {
        closeImagePreview();
      }
    });
    console.log('✅ Modal backdrop listener attached');
  } else {
    console.error('❌ modalBackdrop not found');
  }
  
  // ✅ NEW: Add listener for "Make Parent Image" button
  if (makeParentBtn) {
    makeParentBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      console.log('🎯 Make Parent Image button clicked');
      
      // Get data from button
      const imagePath = e.target.dataset.imagePath;
      const sourceClusterPath = e.target.dataset.sourceClusterPath;
      
      if (imagePath && sourceClusterPath) {
        makeParentImage(imagePath, sourceClusterPath);
      } else {
        console.error('❌ Missing data for makeParentImage');
        alert('Error: Missing required data');
      }
    });
    console.log('✅ Make Parent Image button listener attached');
  } else {
    console.error('❌ makeParentImageBtn not found');
  }
  
  // Close modal on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      console.log('🔴 Escape key pressed');
      closeImagePreview();
    }
  });
  console.log('✅ Escape key listener attached');
  
  // Prompt Editor Modal listeners
  const promptModalCloseBtn = document.getElementById('promptModalCloseBtn');
  const promptModalBackdrop = document.getElementById('promptModalBackdrop');
  const promptEditorCancelBtn = document.getElementById('promptEditorCancelBtn');
  const promptEditorSaveBtn = document.getElementById('promptEditorSaveBtn');
  
  if (promptModalCloseBtn) {
    promptModalCloseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closePromptEditor();
    });
    console.log('✅ Prompt modal close button listener attached');
  }
  
  if (promptModalBackdrop) {
    promptModalBackdrop.addEventListener('click', (e) => {
      if (e.target === promptModalBackdrop) {
        closePromptEditor();
      }
    });
    console.log('✅ Prompt modal backdrop listener attached');
  }
  
  if (promptEditorCancelBtn) {
    promptEditorCancelBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closePromptEditor();
    });
    console.log('✅ Prompt editor cancel button listener attached');
  }
  
  if (promptEditorSaveBtn) {
    promptEditorSaveBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      saveCustomPrompt();
    });
    console.log('✅ Prompt editor save button listener attached');
  }
  
  // Close prompt modal on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const promptModal = document.getElementById('promptEditorModal');
      if (promptModal && promptModal.style.display !== 'none') {
        closePromptEditor();
      }
    }
  });
}

// ============================================
// AI Settings Handlers
// ============================================

async function handleSaveAISettings() {
  try {
    const settings = {
      ollamaEndpoint: document.getElementById('ollamaEndpoint').value,
      ollamaModel: document.getElementById('ollamaModel').value,
      confidenceThreshold: parseInt(document.getElementById('confidenceThreshold').value),
      googleVisionApiKey: document.getElementById('googleVisionApiKey').value
    };
    
    const response = await window.electronAPI.saveAISettings(settings);
    
    if (response.success) {
      alert('✅ AI settings saved successfully!');
    } else {
      alert(`❌ Failed to save settings: ${response.error}`);
    }
    
  } catch (error) {
    console.error('Error saving AI settings:', error);
    alert(`Error: ${error.message}`);
  }
}

async function handleTestGoogleVision() {
  const statusDiv = document.getElementById('googleVisionStatus');
  const apiKey = document.getElementById('googleVisionApiKey').value;
  
  if (!apiKey) {
    statusDiv.style.display = 'block';
    statusDiv.style.color = '#e74c3c';
    statusDiv.textContent = '⚠️ Please enter an API key first';
    return;
  }
  
  try {
    statusDiv.style.display = 'block';
    statusDiv.style.color = '#666';
    statusDiv.textContent = '🔄 Testing connection...';
    
    const response = await window.electronAPI.testGoogleVisionAPI(apiKey);
    
    if (response.success) {
      statusDiv.style.color = '#28a745';
      statusDiv.textContent = '✅ Google Vision API connection successful!';
    } else {
      statusDiv.style.color = '#e74c3c';
      statusDiv.textContent = `❌ Connection failed: ${response.error}`;
    }
    
  } catch (error) {
    console.error('Error testing Google Vision:', error);
    statusDiv.style.display = 'block';
    statusDiv.style.color = '#e74c3c';
    statusDiv.textContent = `❌ Error: ${error.message}`;
  }
}

// ============================================
// AI Analysis Tab Functions
// ============================================

let currentAnalysisData = null; // Store current analysis for editing
let allClustersForAnalysis = [];
let analyzedClusters = new Map(); // clusterIndex → metadata
let currentClusterIndex = null;
let preAnalysisGPS = new Map(); // clusterIndex → GPS data (for GPS added BEFORE AI analysis)

// ============================================
// Cluster Management for AI Analysis
// ============================================

/**
 * Batch analyze all clusters with AI
 * ✅ COMPLETE GPS FIX with full debug logging
 */
async function batchAnalyzeAllClusters() {
  console.log('\n\n🚀 ========================================');
  console.log('    BATCH ANALYSIS WITH GPS SYNC');
  console.log('========================================\n');
  
  // STEP 1: Log initial state
  console.log('📊 STEP 1: Initial State');
  console.log(`   - allProcessedImages count: ${allProcessedImages.length}`);
  console.log(`   - window.processedClusters count: ${window.processedClusters?.length || 0}`);
  
  // STEP 2: Sync GPS from window.processedClusters to allProcessedImages
  console.log('\n🔄 STEP 2: GPS Sync Process');
  let gpsFoundCount = 0;
  let gpsSyncedCount = 0;
  
  if (window.processedClusters && allProcessedImages) {
    // First, check what GPS exists in processedClusters
    console.log('\n   Scanning window.processedClusters for GPS:');
    window.processedClusters.forEach((cluster, idx) => {
      // ✅ FIX: window.processedClusters uses .gps directly (NO mainRep!)
      if (cluster.gps?.latitude) {
        gpsFoundCount++;
        const filename = cluster.representativeFilename || (cluster.representative ? cluster.representative.split('/').pop() : 'Unknown');
        console.log(`   [${idx}] ✅ GPS FOUND: ${filename}`);
        console.log(`                GPS: ${cluster.gps.latitude}, ${cluster.gps.longitude}`);
      }
    });
    
    console.log(`\n   📍 Total GPS coordinates found: ${gpsFoundCount}`);
    
    if (gpsFoundCount === 0) {
      console.warn('\n   ⚠️  WARNING: NO GPS found in processedClusters!');
      console.log('   This means GPS was NOT saved when you edited it.');
      console.log('   Check the updateGPS() function.');
    }
    
    // Now sync to allProcessedImages
    console.log('\n   Syncing to allProcessedImages:');
    allProcessedImages.forEach((group, groupIndex) => {
      const repPath = group.mainRep?.representativePath;
      
      // ✅ FIX: Match using representativePath OR representative (NO mainRep in processedClusters!)
      const processedCluster = window.processedClusters.find(c => 
        c.representativePath === repPath || 
        c.representative === repPath
      );
      
      if (processedCluster && processedCluster.gps?.latitude) {
        // Sync GPS to group
        group.mainRep.gps = {
          latitude: processedCluster.gps.latitude,
          longitude: processedCluster.gps.longitude,
          altitude: processedCluster.gps.altitude || null,
          source: processedCluster.gps.source || 'Manual Entry'
        };
        gpsSyncedCount++;
        console.log(`   [${groupIndex}] ✅ SYNCED: ${group.mainRep.representativeFilename}`);
        console.log(`                    GPS: ${processedCluster.gps.latitude}, ${processedCluster.gps.longitude}`);
      }
    });
    
    console.log(`\n   📍 GPS coordinates synced: ${gpsSyncedCount}/${gpsFoundCount}`);
    
    if (gpsSyncedCount < gpsFoundCount) {
      console.warn(`\n   ⚠️  WARNING: ${gpsFoundCount - gpsSyncedCount} GPS coordinates could not be synced!`);
      console.log('   Path matching may have failed.');
    }
  } else {
    console.error('\n   ❌ ERROR: Missing data structures');
    console.log(`   - window.processedClusters exists: ${!!window.processedClusters}`);
    console.log(`   - allProcessedImages exists: ${!!allProcessedImages}`);
  }
  
  // STEP 3: Deduplicate and prepare for analysis
  console.log('\n📋 STEP 3: Deduplication');
  const uniqueClusters = [];
  const seenPaths = new Set();
  
  allProcessedImages.forEach(group => {
    const repPath = group.mainRep?.representativePath;
    if (!seenPaths.has(repPath)) {
      seenPaths.add(repPath);
      uniqueClusters.push(group);
    }
  });
  
  console.log(`   - Unique clusters: ${uniqueClusters.length}`);
  console.log(`   - Duplicates removed: ${allProcessedImages.length - uniqueClusters.length}`);
  
  // STEP 4: Log GPS status for each cluster
  console.log('\n📍 STEP 4: Final GPS Status Before Analysis');
  let clustersWithGPS = 0;
  uniqueClusters.forEach((group, idx) => {
    const hasGPS = !!group.mainRep?.gps?.latitude;
    if (hasGPS) {
      clustersWithGPS++;
      console.log(`   [${idx}] ✅ ${group.mainRep.representativeFilename}`);
      console.log(`            GPS: ${group.mainRep.gps.latitude}, ${group.mainRep.gps.longitude}`);
    } else {
      console.log(`   [${idx}] ⚪ ${group.mainRep.representativeFilename} - NO GPS`);
    }
  });
  
  console.log(`\n   📍 Clusters with GPS: ${clustersWithGPS}/${uniqueClusters.length}`);
  
  if (clustersWithGPS === 0 && gpsFoundCount > 0) {
    console.error('\n   🔴 CRITICAL ERROR: GPS was found but not in any clusters!');
    console.log('   This indicates the sync failed completely.');
  }
  
  // STEP 5: Run AI Analysis
  console.log('\n\n🤖 STEP 5: Starting AI Analysis');
  console.log('========================================\n');
  
  analyzedClusters.clear();
  allClustersForAnalysis = uniqueClusters;
  
  // ============================================================================
  // 🔍 STEP 3: BEFORE AI ANALYSIS - Track derivatives before analysis
  // ============================================================================
  console.log('\n🔍 ========== STEP 3: BEFORE AI ANALYSIS ==========');
  let step3Derivs = 0;
  let step3Files = 0;
  let step3Reps = 0;
  allClustersForAnalysis.forEach((group, idx) => {
    const mainDerivs = group.mainRep?.derivatives?.length || 0;
    const mainImages = group.mainRep?.imagePaths?.length || 0;
    step3Derivs += mainDerivs;
    step3Files += mainImages;
    step3Reps += 1;
    
    if (group.similarReps) {
      group.similarReps.forEach(sim => {
        const simDerivs = sim.cluster?.derivatives?.length || 0;
        const simImages = sim.cluster?.imagePaths?.length || 0;
        step3Derivs += simDerivs;
        step3Files += simImages;
        step3Reps += 1;
      });
    }
  });
  console.log(`📊 Total before analysis: ${step3Reps} reps + ${step3Files} images + ${step3Derivs} derivatives`);
  console.log(`📊 GRAND TOTAL: ${step3Reps + step3Files + step3Derivs} files`);
  console.log(`📊 EXPECTED: 78 files`);
  console.log(`📊 DIFFERENCE: ${78 - (step3Reps + step3Files + step3Derivs)} files ${78 - (step3Reps + step3Files + step3Derivs) > 0 ? 'MISSING' : 'EXTRA'}`);
  console.log('🔍 ==========================================\n');
  // ============================================================================
  
  // ============================================================================
  // 🔍 DIAGNOSTIC: Check if derivatives exist in cluster data
  // ============================================================================
  console.log('\n🔍 ========== DERIVATIVE DIAGNOSTIC ==========');
  console.log(`Total clusters: ${allClustersForAnalysis.length}`);
  
  allClustersForAnalysis.forEach((group, idx) => {
    console.log(`\n📦 Cluster ${idx + 1}: ${group.mainRep?.representativeFilename}`);
    console.log('   Structure check:');
    console.log('   - Has mainRep?', !!group.mainRep);
    console.log('   - Has imagePaths?', !!group.mainRep?.imagePaths);
    console.log('   - imagePaths count:', group.mainRep?.imagePaths?.length || 0);
    console.log('   - Has derivatives?', !!group.mainRep?.derivatives);
    console.log('   - Derivatives count:', group.mainRep?.derivatives?.length || 0);
    
    if (group.mainRep?.derivatives && group.mainRep.derivatives.length > 0) {
      console.log('   ✅ DERIVATIVES FOUND:');
      group.mainRep.derivatives.forEach(d => {
        console.log('      -', d.split('/').pop());
      });
    } else {
      console.log('   ❌ NO DERIVATIVES in mainRep');
    }
    
    // Check similar reps too
    if (group.similarReps && group.similarReps.length > 0) {
      console.log(`   Similar reps: ${group.similarReps.length}`);
      group.similarReps.forEach((sim, simIdx) => {
        console.log(`   - Similar ${simIdx + 1}: ${sim.cluster?.representativeFilename}`);
        console.log(`     Derivatives: ${sim.cluster?.derivatives?.length || 0}`);
        if (sim.cluster?.derivatives && sim.cluster.derivatives.length > 0) {
          sim.cluster.derivatives.forEach(d => {
            console.log('        -', d.split('/').pop());
          });
        }
      });
    }
  });
  
  console.log('\n🔍 ========== END DIAGNOSTIC ==========\n');
  // ============================================================================
  
  for (let i = 0; i < uniqueClusters.length; i++) {
    const group = uniqueClusters[i];
    const clusterName = group.mainRep?.representativeFilename || `Cluster ${i + 1}`;
    
    try {
      console.log(`\n[${i + 1}/${uniqueClusters.length}] Analyzing: ${clusterName}`);
      
      // Log GPS being sent
      if (group.mainRep?.gps?.latitude) {
        console.log(`   📍 GPS will be sent to AI:`);
        console.log(`      Lat: ${group.mainRep.gps.latitude}`);
        console.log(`      Lon: ${group.mainRep.gps.longitude}`);
      } else {
        console.log(`   ⚪ No GPS for this cluster`);
      }
      
      updateStatus(`Analyzing cluster ${i + 1} of ${uniqueClusters.length}: ${clusterName}...`, 'processing');
      showProgress(Math.round(((i + 1) / uniqueClusters.length) * 100));
      
      // Call backend - GPS is in group.mainRep.gps
      const result = await window.electronAPI.analyzeClusterWithAI(group);
      
      if (result.success) {
        analyzedClusters.set(i, result.data.metadata);
        console.log(`   ✅ Analysis complete`);
        
        // Log if GPS came back in metadata
        if (result.data.metadata.gpsAnalysis?.latitude) {
          console.log(`   📍 AI returned GPS: ${result.data.metadata.gpsAnalysis.latitude}, ${result.data.metadata.gpsAnalysis.longitude}`);
        }
      } else {
        console.error(`   ❌ Analysis failed: ${result.error}`);
        alert(`Analysis failed for ${clusterName}: ${result.error}`);
      }
      
    } catch (error) {
      console.error(`   ❌ Error: ${error.message}`);
      alert(`Error analyzing ${clusterName}: ${error.message}`);
    }
  }
  
  console.log('\n\n✅ ========================================');
  console.log('    BATCH ANALYSIS COMPLETE');
  console.log('========================================\n');
  
  updateStatus('All clusters analyzed!', 'complete');
  showProgress(100);
  
  loadClustersForAnalysis();
}

/**
 * Load all clusters into AI Analysis tab with thumbnail grid
 */
function loadClustersForAnalysis() {
  // Check if we have clusters (either from batch analysis or from allProcessedImages)
  const sourceClusters = allClustersForAnalysis.length > 0 ? allClustersForAnalysis : allProcessedImages;
  const generateBtn = document.getElementById('generateAllXMPBtn');
  
  if (!sourceClusters || sourceClusters.length === 0) {
    // Show empty state, hide button
    document.getElementById('aiAnalysisEmpty').style.display = 'block';
    document.getElementById('clusterSelectionSection').style.display = 'none';
    if (generateBtn) generateBtn.style.display = 'none';
    return;
  }
  
  // ✅ DEDUPLICATE - Remove duplicate super clusters
  const uniqueClusters = [];
  const seenPaths = new Set();
  
  sourceClusters.forEach(group => {
    const repPath = group.mainRep?.representativePath;
    if (repPath && !seenPaths.has(repPath)) {
      seenPaths.add(repPath);
      uniqueClusters.push(group);
    }
  });
  
  allClustersForAnalysis = uniqueClusters;
  
  console.log(`✅ Loaded ${uniqueClusters.length} unique super clusters (${analyzedClusters.size} analyzed)`);
  
  // Show cluster grid and button
  document.getElementById('aiAnalysisEmpty').style.display = 'none';
  document.getElementById('clusterSelectionSection').style.display = 'block';
  if (generateBtn) generateBtn.style.display = 'block';
  document.getElementById('aiAnalysisResults').style.display = 'none';
  
  // Hide confidence badge when showing cluster grid
  const confidenceInline = document.getElementById('aiConfidenceInline');
  if (confidenceInline) confidenceInline.style.display = 'none';
  
  renderClusterThumbnailGrid();
}

/**
 * Render thumbnail grid of all clusters
 */
async function renderClusterThumbnailGrid() {
  const grid = document.getElementById('clusterThumbnailGrid');
  
  // ✅ FORCE CLEAR - Remove all children completely
  while (grid.firstChild) {
    grid.removeChild(grid.firstChild);
  }
  
  console.log('🎨 === RENDERING THUMBNAIL GRID ===');
  console.log('📊 allClustersForAnalysis.length:', allClustersForAnalysis.length);
  console.log('📋 allClustersForAnalysis:', allClustersForAnalysis.map(g => g.mainRep?.representativeFilename));
  
  for (let i = 0; i < allClustersForAnalysis.length; i++) {
    const group = allClustersForAnalysis[i];
    console.log(`  Rendering card ${i}: ${group.mainRep?.representativeFilename}`);
    
    const card = document.createElement('div');
    card.className = 'cluster-thumbnail-card';
    
    if (analyzedClusters.has(i)) {
      card.classList.add('analyzed');
    }
    
    if (i === currentClusterIndex) {
      card.classList.add('current');
    }
    
    // Thumbnail
    const img = document.createElement('img');
    img.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="150" viewBox="0 0 24 24" fill="none" stroke="%236c757d" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
    
    // Load actual thumbnail
    const repPath = group.mainRep.representativePath;
    const result = await window.electronAPI.getPreviewImage(repPath);
    if (result.success) {
      img.src = result.dataUrl;
    }
    
    // Info
    const info = document.createElement('div');
    info.className = 'cluster-thumbnail-info';
    info.textContent = group.mainRep.representativeFilename;
    
    // Action buttons container
    const actionsContainer = document.createElement('div');
    actionsContainer.className = 'cluster-actions';
    
    // Analyze with AI button
    const analyzeBtn = document.createElement('button');
    analyzeBtn.className = 'analyze-ai-btn';
    analyzeBtn.innerHTML = `
      <svg class="ai-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z"/>
        <path d="M2 17l10 5 10-5"/>
        <path d="M2 12l10 5 10-5"/>
      </svg>
      Analyze with AI
    `;
    analyzeBtn.onclick = (e) => {
      e.stopPropagation();
      analyzeClusterWithCustomPrompt(group);
    };
    
    // View/Edit Prompt button
    const promptBtn = document.createElement('button');
    promptBtn.className = 'view-prompt-btn';
    promptBtn.setAttribute('data-cluster-path', group.mainRep.representativePath);
    promptBtn.innerHTML = `
      <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      View Prompt
    `;
    promptBtn.onclick = (e) => {
      e.stopPropagation();
      showPromptEditor(group);
    };
    
    // Update button state based on custom prompt
    updatePromptButtonState(group.mainRep.representativePath);
    
    actionsContainer.appendChild(analyzeBtn);
    actionsContainer.appendChild(promptBtn);
    
    card.appendChild(img);
    card.appendChild(info);
    card.appendChild(actionsContainer);
    
    // Click handler for card (select cluster)
    card.onclick = () => selectCluster(i);
    
    grid.appendChild(card);
    console.log(`  ✅ Card ${i} appended to grid`);
  }
  
  console.log(`🎨 Total cards in grid: ${grid.children.length}`);
  console.log('🎨 === END RENDERING ===\n');
  
  // Update "Generate All" button state
  updateGenerateAllButtonState();
}

/**
 * Select a cluster for analysis/editing
 */
async function selectCluster(clusterIndex) {
  console.log('🎯 selectCluster called with index:', clusterIndex);
  
  // ✅ SIMPLE FIX: Save current cluster FIRST before doing anything else
  if (currentClusterIndex !== null && currentClusterIndex !== clusterIndex) {
    try {
      console.log('💾 Auto-saving current cluster', currentClusterIndex, 'before switching');
      
      // Force blur on ANY active element to ensure values are committed to DOM
      if (document.activeElement) {
        document.activeElement.blur();
      }
      
      // Wait 50ms for blur to complete and DOM to update
      await new Promise(resolve => setTimeout(resolve, 50));
      
      // Now collect metadata
      const editedMetadata = collectMetadataFromForm();
      analyzedClusters.set(currentClusterIndex, editedMetadata);
      
      console.log('✅ Auto-saved metadata:', editedMetadata);
    } catch (error) {
      console.error('❌ Failed to auto-save metadata:', error);
    }
  }
  
  // Now proceed with switching
  currentClusterIndex = clusterIndex;
  const group = allClustersForAnalysis[clusterIndex];
  
  if (!group) {
    console.error('❌ No cluster found at index:', clusterIndex);
    return;
  }
  
  // Check if analyzed
  if (!analyzedClusters.has(clusterIndex)) {
    alert('This cluster has not been analyzed yet. Please run "Run AI Analysis" first.');
    return;
  }
  
  // Load metadata for selected cluster
  const savedMetadata = analyzedClusters.get(clusterIndex);
  
  console.log('✅ Loading metadata for:', group.mainRep?.representativeFilename);
  
  displayAIAnalysisResults({
    cluster: group,
    metadata: savedMetadata,
    affectedImages: getAllAffectedPaths(group),
    imageCount: countTotalImages(group),
    breakdown: {
      parents: 1 + (group.similarReps?.length || 0),
      children: countChildren(group)
    }
  });
  
  // Show results
  document.getElementById('aiAnalysisResults').style.display = 'block';
  
  // Update visual selection
  updateThumbnailSelection(clusterIndex);
  
  console.log('✅ Selection complete, currentClusterIndex:', currentClusterIndex);
}

/**
 * Update thumbnail selection visual state
 */
function updateThumbnailSelection(selectedIndex) {
  const cards = document.querySelectorAll('.cluster-thumbnail-card');
  cards.forEach((card, idx) => {
    if (idx === selectedIndex) {
      card.classList.add('current');
    } else {
      card.classList.remove('current');
    }
  });
}

/**
 * Save current metadata (called when switching between clusters)
 */
function backToClusterSelection() {
  // Save current metadata if edited
  if (currentClusterIndex !== null) {
    const editedMetadata = collectMetadataFromForm();
    analyzedClusters.set(currentClusterIndex, editedMetadata);
    console.log(`💾 Auto-saved metadata for cluster ${currentClusterIndex}`);
  }
  
  // Update button states
  updateGenerateAllButtonState();
}

/**
 * Save metadata for current cluster
 */
function saveCurrentClusterMetadata() {
  if (currentClusterIndex === null) return;
  
  const metadata = collectMetadataFromForm();
  analyzedClusters.set(currentClusterIndex, metadata);
  
  alert('✅ Metadata saved for this cluster!');
  
  // Update button states
  updateGenerateAllButtonState();
  
  // Re-render thumbnails to update status
  renderClusterThumbnailGrid();
  
  // ❌ DON'T GO BACK - stay on current cluster (thumbnails always visible)
}

/**
 * Update "Generate All XMP" button state
 */
function updateGenerateAllButtonState() {
  const btn = document.getElementById('generateAllXMPBtn');
  const status = document.getElementById('xmpGenerationStatus');
  
  if (!btn || !status) return;
  
  const totalClusters = allClustersForAnalysis.length;
  const analyzedCount = analyzedClusters.size;
  
  if (analyzedCount === 0) {
    btn.disabled = true;
    status.textContent = `No clusters analyzed yet (0/${totalClusters})`;
  } else if (analyzedCount < totalClusters) {
    btn.disabled = false;
    status.textContent = `Ready to generate for ${analyzedCount}/${totalClusters} clusters`;
    status.style.color = '#ffc107';
  } else {
    btn.disabled = false;
    status.textContent = '';
    status.style.color = '#28a745';
  }
}

/**
 * Generate XMP for all analyzed clusters
 */
/**
 * Generate XMP for all analyzed clusters
 * Updated version: removes popups, tracks total XMP files, updates button state
 */
async function generateAllXMPFiles() {
  if (analyzedClusters.size === 0) {
    alert('No clusters have been analyzed yet.');
    return;
  }
  
  // ❌ REMOVED: Confirmation dialog popup
  
  const btn = document.getElementById('generateAllXMPBtn');
  const status = document.getElementById('xmpGenerationStatus');
  
  btn.disabled = true;
  btn.textContent = '⏳ Generating XMP Files...';
  
  let successCount = 0;
  let failCount = 0;
  let totalXMPsCreated = 0; // ✅ NEW: Track total XMP files, not clusters
  
  for (const [clusterIndex, metadata] of analyzedClusters.entries()) {
    const group = allClustersForAnalysis[clusterIndex];
    
    try {
      status.textContent = `Processing cluster ${successCount + failCount + 1}/${analyzedClusters.size}...`;
      
      const result = await window.electronAPI.generateXMPFiles({
        cluster: group,
        metadata: metadata,
        affectedImages: getAllAffectedPaths(group)
      });
      
      if (result.success) {
        successCount++;
        totalXMPsCreated += result.filesProcessed || 0; // ✅ NEW: Add actual file count
      } else {
        failCount++;
      }
      
    } catch (error) {
      console.error('XMP generation failed for cluster:', error);
      failCount++;
    }
  }
  
  // ✅ NEW: Change button to grey "XMPs Created" state and keep disabled
  btn.style.background = '#6c757d'; // Grey background
  btn.style.cursor = 'not-allowed';
  btn.textContent = 'XMPs Created';
  // Keep btn.disabled = true (don't re-enable)
  
  // ❌ REMOVED: Alert popup showing success/failed counts
  
  // ✅ NEW: Update status to show total XMP files created
  status.textContent = `${totalXMPsCreated} XMP files created`;
  status.style.color = '#28a745';
}

/**
 * Helper: Get all image paths affected by a cluster
 * ✅ FIXED: Now includes derivatives (TIF, PSD)
 */
function getAllAffectedPaths(group) {
  const paths = [group.mainRep.representativePath];
  
  // Main rep's bracketed images
  if (group.mainRep.imagePaths) {
    paths.push(...group.mainRep.imagePaths.filter(p => p !== group.mainRep.representativePath));
  }
  
  // ✅ FIX: Add main rep's derivatives
  if (group.mainRep.derivatives) {
    paths.push(...group.mainRep.derivatives);
  }
  
  // Similar representatives and their files
  if (group.similarReps) {
    group.similarReps.forEach(sim => {
      paths.push(sim.cluster.representativePath);
      
      // Similar rep's bracketed images
      if (sim.cluster.imagePaths) {
        paths.push(...sim.cluster.imagePaths);
      }
      
      // ✅ FIX: Add similar rep's derivatives
      if (sim.cluster.derivatives) {
        paths.push(...sim.cluster.derivatives);
      }
    });
  }
  
  const uniquePaths = [...new Set(paths)];
  
  // ============================================================================
  // 🔍 STEP 4: getAllAffectedPaths RESULT - Final path collection
  // ============================================================================
  console.log('\n🔍 ========== STEP 4: getAllAffectedPaths RESULT ==========');
  console.log(`📊 Total paths collected: ${uniquePaths.length}`);
  console.log(`📊 EXPECTED: 78 files`);
  console.log(`📊 DIFFERENCE: ${78 - uniquePaths.length} files ${78 - uniquePaths.length > 0 ? 'MISSING' : 'EXTRA'}`);
  console.log('Files collected:', uniquePaths.map(p => p.split('/').pop()));
  console.log('🔍 ==========================================\n');
  // ============================================================================
  
  return uniquePaths;
}

/**
 * Helper: Count total images in a cluster
 */
function countTotalImages(group) {
  return getAllAffectedPaths(group).length;
}

/**
 * Helper: Count child images in a cluster
 */
function countChildren(group) {
  let total = 0;
  if (group.mainRep.isBracketed && group.mainRep.imageCount) {
    total += group.mainRep.imageCount - 1;
  }
  if (group.similarReps) {
    group.similarReps.forEach(sim => {
      if (sim.cluster.isBracketed && sim.cluster.imageCount) {
        total += sim.cluster.imageCount;
      }
    });
  }
  return total;
}

/**
 * Trigger AI analysis from Visual Analysis tab
 * Called when user clicks "Analyze with AI" button on a cluster
 */
async function analyzeClusterWithAI(clusterGroup) {
  try {
    console.log('Starting AI analysis for cluster:', clusterGroup.mainRep.representativeFilename);
    
    // Find and disable the button that triggered this (visual feedback)
    const buttons = document.querySelectorAll('.analyze-ai-btn');
    buttons.forEach(btn => {
      btn.disabled = true;
      btn.classList.add('loading');
      btn.innerHTML = `
        <svg class="ai-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/>
          <path d="M12 6v6l4 2"/>
        </svg>
        Analyzing...
      `;
    });
    
    // Show loading state
    updateStatus('Analyzing with AI...', 'processing');
    showProgress(0);
    
    // Ensure currentClusterIndex is set for GPS priority lookups
    const groupIndex = allProcessedImages.findIndex(g => g.mainRep?.representativePath === clusterGroup.mainRep?.representativePath);
    if (groupIndex !== -1) {
      currentClusterIndex = groupIndex;
    }

    // Merge pre-analysis GPS into the group before sending to backend
    if (groupIndex !== -1 && preAnalysisGPS.has(groupIndex)) {
      const gpsData = preAnalysisGPS.get(groupIndex);
      if (!clusterGroup.mainRep.gps) {
        clusterGroup.mainRep.gps = gpsData;
        console.log('✅ Injected pre-analysis GPS into clusterGroup before AI call:', gpsData);
      }
    }

    // Call backend AI analysis with GPS in payload if present
    const result = await window.electronAPI.analyzeClusterWithAI(clusterGroup);
    
    showProgress(100);
    
    if (result.success) {
      console.log('AI analysis complete:', result.data);
      
      // Store analysis data globally
      currentAnalysisData = result.data;

      // Also merge pre-analysis GPS into analysis result for display priority
      if (groupIndex !== -1 && preAnalysisGPS.has(groupIndex)) {
        const gpsData = preAnalysisGPS.get(groupIndex);
        if (!currentAnalysisData.metadata.manualGPS && gpsData?.latitude) {
          currentAnalysisData.metadata.manualGPS = gpsData;
          console.log('✅ Merged pre-analysis GPS into analysis metadata for display:', gpsData);
        }
      }
      
      // Display results in AI Analysis tab
      displayAIAnalysisResults(result.data);
      
      // Switch to AI Analysis tab
      const aiAnalysisTab = document.querySelector('[data-tab="ai-analysis"]');
      if (aiAnalysisTab) {
        aiAnalysisTab.click();
      }
      
      updateStatus('AI analysis complete!', 'complete');
      
    } else {
      throw new Error(result.error || 'AI analysis failed');
    }
    
  } catch (error) {
    console.error('AI analysis failed:', error);
    updateStatus(`AI analysis failed: ${error.message}`, 'error');
    alert(`AI analysis failed: ${error.message}`);
  } finally {
    // Re-enable all buttons
    const buttons = document.querySelectorAll('.analyze-ai-btn');
    buttons.forEach(btn => {
      btn.disabled = false;
      btn.classList.remove('loading');
      btn.innerHTML = `
        <svg class="ai-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 2L2 7l10 5 10-5-10-5z"/>
          <path d="M2 17l10 5 10-5"/>
          <path d="M2 12l10 5 10-5"/>
        </svg>
        Analyze with AI
      `;
    });
  }
}

/**
 * Display AI analysis results in the UI
 */
function displayAIAnalysisResults(analysisData) {
  console.log('Displaying AI analysis results');
  
  // Hide empty state, show results
  document.getElementById('aiAnalysisEmpty').style.display = 'none';
  document.getElementById('aiAnalysisResults').style.display = 'block';
  
  // Update inline confidence indicator
  const confidenceInline = document.getElementById('aiConfidenceInline');
  if (confidenceInline && analysisData.metadata.confidence) {
    const confidence = analysisData.metadata.confidence;
    const provider = analysisData.metadata.provider === 'google_vision' ? 'Google' : 'Ollama';
    
    confidenceInline.textContent = `${provider}: ${confidence}%`;
    
    // Color based on confidence
    if (confidence >= 90) {
      confidenceInline.style.background = '#d4edda';
      confidenceInline.style.color = '#155724';
    } else if (confidence >= 80) {
      confidenceInline.style.background = '#d1ecf1';
      confidenceInline.style.color = '#0c5460';
    } else {
      confidenceInline.style.background = '#fff3cd';
      confidenceInline.style.color = '#856404';
    }
    
    confidenceInline.style.display = 'inline-block';
  }
  
  // Populate metadata fields
  populateMetadataFields(analysisData.metadata);
  
  // Display static metadata
  displayStaticMetadata(analysisData);
  
  // Show/hide low confidence warning
  const threshold = 85; // Get from config
  if (analysisData.metadata.confidence < threshold) {
    showLowConfidenceWarning(analysisData.metadata.confidence, threshold);
  } else {
    document.getElementById('lowConfidenceWarning').style.display = 'none';
  }
}

/**
 * Display preview image
 */
async function displayPreviewImage(analysisData) {
  const previewImg = document.getElementById('aiPreviewImage');
  const filenameEl = document.getElementById('aiPreviewFilename');
  const imageCountEl = document.getElementById('aiPreviewImageCount');
  
  // Get representative image path
  const repPath = analysisData.cluster.mainRep.representativePath;
  const filename = repPath.split('/').pop();
  
  // Load thumbnail
  const result = await window.electronAPI.getPreviewImage(repPath);
  if (result.success) {
    previewImg.src = result.dataUrl;
  }
  
  // Display filename
  filenameEl.textContent = filename;
  
  // Display image count
  const totalImages = analysisData.imageCount;
  const parents = analysisData.breakdown.parents;
  const children = analysisData.breakdown.children;
  
  imageCountEl.textContent = `📦 This XMP will be applied to ${totalImages} images (${parents} parent${parents > 1 ? 's' : ''}, ${children} child${children !== 1 ? 'ren' : ''})`;
}

/**
 * Display confidence score with color coding
 */
function displayConfidenceScore(metadata) {
  const confidenceSection = document.getElementById('confidenceSection');
  const providerEl = document.getElementById('confidenceProvider');
  const scoreEl = document.getElementById('confidenceScore');
  const fillEl = document.getElementById('confidenceFill');
  const messageEl = document.getElementById('confidenceMessage');
  
  const confidence = metadata.confidence;
  
  // Set provider icon and name
  const providerIcon = metadata.provider === 'google_vision' ? '🌐' : '🤖';
  const providerName = metadata.provider === 'google_vision' ? 'Google Vision' : 'Ollama';
  providerEl.textContent = `${providerIcon} ${providerName}`;
  
  // Set confidence score
  scoreEl.textContent = `${confidence}%`;
  
  // Set progress bar width
  fillEl.style.width = `${confidence}%`;
  
  // Determine confidence level and apply styling
  let level, message;
  
  if (confidence >= 90) {
    level = 'excellent';
    message = '✅ Excellent confidence - Results are highly accurate';
  } else if (confidence >= 80) {
    level = 'good';
    message = 'ℹ️ Good confidence - Results are likely accurate';
  } else if (confidence >= 70) {
    level = 'fair';
    message = '⚠️ Fair confidence - Review results carefully';
  } else {
    level = 'poor';
    message = '❌ Low confidence - Consider using Google Vision or manual editing';
  }
  
  // Apply confidence class
  confidenceSection.className = `confidence-indicator confidence-${level}`;
  fillEl.className = `confidence-fill ${level}`;
  messageEl.textContent = message;
}

/**
 * Show low confidence warning
 */
function showLowConfidenceWarning(confidence, threshold) {
  const warningDiv = document.getElementById('lowConfidenceWarning');
  warningDiv.style.display = 'block';
  
  const warningText = warningDiv.querySelector('p:nth-of-type(2)');
  warningText.textContent = `Analysis confidence (${confidence}%) is below the threshold (${threshold}%). You can:`;
}

/**
 * Populate all metadata fields
 */
function populateMetadataFields(metadata) {
  // Title
  document.getElementById('metaTitle').value = metadata.title || '';
  
  // Description
  document.getElementById('metaDescription').value = metadata.description || '';
  
  // Caption
  document.getElementById('metaCaption').value = metadata.caption || '';
  
  // Keywords
  populateKeywords(metadata.keywords || []);
  
  // Category & Scene Type
  document.getElementById('metaCategory').value = metadata.category || '';
  document.getElementById('metaSceneType').value = metadata.sceneType || '';
  
  // Mood
  document.getElementById('metaMood').value = metadata.mood || '';
  
  // Location
  if (metadata.location) {
    document.getElementById('metaCity').value = metadata.location.city || '';
    document.getElementById('metaState').value = metadata.location.state || '';
    document.getElementById('metaCountry').value = metadata.location.country || '';
    document.getElementById('metaSpecificLocation').value = metadata.location.specificLocation || '';
  }
  
  // GPS coordinates - Check multiple sources with priority:
  // 1. Manual GPS (user edited on AI Analysis page)
  // 2. GPS from Visual Analysis page (pre-analysis)
  // 3. GPS from cluster mainRep (saved during visual analysis)
  // 4. GPS Analysis from AI
  // 5. EXIF GPS from parent
  let gpsData = null;
  let gpsSource = '';
  
  console.log('🔍 Checking GPS sources for cluster', currentClusterIndex);
  console.log('   metadata.manualGPS:', metadata.manualGPS);
  console.log('   currentClusterIndex:', currentClusterIndex);
  console.log('   Has preAnalysisGPS:', currentClusterIndex !== null && preAnalysisGPS.has(currentClusterIndex));
  
  if (metadata.manualGPS?.latitude) {
    gpsData = metadata.manualGPS;
    gpsSource = 'Manual Entry';
    console.log('   ✅ Using metadata.manualGPS');
  } else if (currentClusterIndex !== null && preAnalysisGPS.has(currentClusterIndex)) {
    gpsData = preAnalysisGPS.get(currentClusterIndex);
    gpsSource = 'Manual Entry (Pre-Analysis)';
    console.log('   ✅ Using preAnalysisGPS Map');
  } else if (currentClusterIndex !== null && allClustersForAnalysis[currentClusterIndex]?.mainRep?.gps) {
    gpsData = allClustersForAnalysis[currentClusterIndex].mainRep.gps;
    gpsSource = 'Manual Entry (Visual Analysis)';
    console.log('   ✅ Using allClustersForAnalysis[currentClusterIndex].mainRep.gps');
  } else if (metadata.gpsAnalysis?.latitude) {
    gpsData = {
      latitude: parseFloat(metadata.gpsAnalysis.latitude),
      longitude: parseFloat(metadata.gpsAnalysis.longitude),
      altitude: metadata.gpsAnalysis.altitude || null
    };
    gpsSource = 'AI Analysis';
    console.log('   ✅ Using metadata.gpsAnalysis');
  } else if (currentAnalysisData?.cluster?.mainRep?.gps) {
    gpsData = currentAnalysisData.cluster.mainRep.gps;
    gpsSource = 'EXIF Data';
    console.log('   ✅ Using currentAnalysisData.cluster.mainRep.gps');
  }
  
  console.log('   📍 Final GPS for display:', gpsData);
  displayGPSSection(gpsData, gpsSource);
  
  // Hashtags
  const hashtags = metadata.hashtags || [];
  document.getElementById('metaHashtags').value = hashtags.join(' ');
  
  // Alt Text
  document.getElementById('metaAltText').value = metadata.altText || '';
}

/**
 * Display GPS section with edit capability
 * ✅ NEW: Light blue design with simple element updates
 */
function displayGPSSection(gpsData, source) {
  console.log('🔍 displayGPSSection called:', gpsData);
  
  const gpsSection = document.getElementById('gpsSection');
  const gpsLatDisplay = document.getElementById('gpsLatDisplay');
  const gpsLonDisplay = document.getElementById('gpsLonDisplay');
  const gpsLat = document.getElementById('gpsLat');
  const gpsLon = document.getElementById('gpsLon');
  const gpsSourceBadge = document.getElementById('gpsSourceBadge');
  
  // Check if GPS section exists
  if (!gpsSection) {
    console.error('❌ gpsSection element not found in DOM');
    return;
  }
  
  // Enhanced GPS data validation
  const hasValidGPS = gpsData && 
                     typeof gpsData === 'object' && 
                     (gpsData.latitude !== undefined && gpsData.latitude !== null);
  
  if (!hasValidGPS) {
    console.log('⚠️ No valid GPS data to display. GPS data:', gpsData);
    gpsSection.style.display = 'none';
    if (gpsLatDisplay) gpsLatDisplay.textContent = '--';
    if (gpsLonDisplay) gpsLonDisplay.textContent = '--';
    if (gpsLat) gpsLat.value = '';
    if (gpsLon) gpsLon.value = '';
    return;
  }
  
  // Display the GPS data
  gpsSection.style.display = 'block';
  if (gpsLatDisplay) gpsLatDisplay.textContent = `${gpsData.latitude}°`;
  if (gpsLonDisplay) gpsLonDisplay.textContent = `${gpsData.longitude}°`;
  if (gpsLat) gpsLat.value = gpsData.latitude;
  if (gpsLon) gpsLon.value = gpsData.longitude;
  if (gpsSourceBadge) gpsSourceBadge.textContent = source || 'Manual Entry';
  
  console.log('✅ GPS displayed successfully:', gpsData.latitude, gpsData.longitude);
}

/**
 * Edit GPS - Toggle between display and edit mode
 */
function editGPS() {
  const gpsDisplay = document.getElementById('gpsDisplay');
  const gpsInput = document.getElementById('gpsInput');
  
  if (gpsDisplay && gpsInput) {
    gpsDisplay.style.display = 'none';
    gpsInput.style.display = 'block';
  }
}

/**
 * Save GPS coordinates
 */
function saveGPS() {
  const gpsLat = document.getElementById('gpsLat');
  const gpsLon = document.getElementById('gpsLon');
  
  if (!gpsLat || !gpsLon) {
    console.error('GPS input fields not found');
    return;
  }
  
  const latitude = parseFloat(gpsLat.value);
  const longitude = parseFloat(gpsLon.value);
  
  if (isNaN(latitude) || isNaN(longitude)) {
    alert('Please enter valid GPS coordinates');
    return;
  }
  
  if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
    alert('GPS coordinates out of range.\nLatitude: -90 to 90\nLongitude: -180 to 180');
    return;
  }
  
  const gpsData = {
    latitude,
    longitude,
    source: 'Manual Entry'
  };
  
  // Save to current analysis data
  if (currentAnalysisData && currentAnalysisData.metadata) {
    currentAnalysisData.metadata.manualGPS = gpsData;
    console.log('✅ GPS saved to currentAnalysisData.metadata.manualGPS:', gpsData);
  }
  
  // Update display
  displayGPSSection(gpsData, 'Manual Entry');
  
  // Switch back to display mode
  const gpsDisplay = document.getElementById('gpsDisplay');
  const gpsInput = document.getElementById('gpsInput');
  if (gpsDisplay && gpsInput) {
    gpsDisplay.style.display = 'block';
    gpsInput.style.display = 'none';
  }
}

/**
 * View GPS coordinates on Google Maps
 */
function viewOnMap() {
  const gpsLatDisplay = document.getElementById('gpsLatDisplay');
  const gpsLonDisplay = document.getElementById('gpsLonDisplay');
  
  if (!gpsLatDisplay || !gpsLonDisplay) {
    alert('GPS coordinates not available');
    return;
  }
  
  const lat = gpsLatDisplay.textContent.replace('°', '').trim();
  const lon = gpsLonDisplay.textContent.replace('°', '').trim();
  
  if (lat && lon && lat !== '--' && lon !== '--') {
    const url = `https://www.google.com/maps?q=${lat},${lon}`;
    window.electronAPI.openExternal(url);
  }
}

/**
 * Copy GPS coordinates to clipboard
 */
function copyGPSCoordinates() {
  const gpsLatDisplay = document.getElementById('gpsLatDisplay');
  const gpsLonDisplay = document.getElementById('gpsLonDisplay');
  
  if (!gpsLatDisplay || !gpsLonDisplay) {
    alert('GPS coordinates not available');
    return;
  }
  
  const lat = gpsLatDisplay.textContent.replace('°', '').trim();
  const lon = gpsLonDisplay.textContent.replace('°', '').trim();
  
  if (lat && lon && lat !== '--' && lon !== '--') {
    const text = `${lat}, ${lon}`;
    navigator.clipboard.writeText(text).then(() => {
      alert('GPS coordinates copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy:', err);
      alert('Failed to copy coordinates');
    });
  }
}

/**
 * Show GPS edit form (OLD - kept for compatibility)
 */
function showGPSEditForm(currentGPS, source) {
  const gpsSection = document.getElementById('gpsDisplaySection');
  
  gpsSection.innerHTML = `
    <div style="background: #fff3cd; padding: 15px; border-radius: 8px; margin-top: 15px; border-left: 4px solid #ffc107;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <strong style="color: #856404;">📍 Edit GPS Coordinates</strong>
        <span style="font-size: 11px; color: #856404;">Will apply to ALL cluster images</span>
        </div>
      
      <div style="display: grid; gap: 10px;">
        <div>
          <label style="display: block; font-size: 13px; color: #856404; margin-bottom: 4px;">Latitude (decimal degrees)</label>
          <input type="number" id="gpsLatInput" step="0.000001" placeholder="51.389167" 
                 value="${currentGPS?.latitude || ''}"
                 style="width: 100%; padding: 8px; border: 1px solid #ffc107; border-radius: 4px;">
          <span style="font-size: 11px; color: #856404;">North: positive, South: negative</span>
        </div>
        
        <div>
          <label style="display: block; font-size: 13px; color: #856404; margin-bottom: 4px;">Longitude (decimal degrees)</label>
          <input type="number" id="gpsLonInput" step="0.000001" placeholder="30.099444"
                 value="${currentGPS?.longitude || ''}"
                 style="width: 100%; padding: 8px; border: 1px solid #ffc107; border-radius: 4px;">
          <span style="font-size: 11px; color: #856404;">East: positive, West: negative</span>
        </div>
        
        <div>
          <label style="display: block; font-size: 13px; color: #856404; margin-bottom: 4px;">Altitude (meters, optional)</label>
          <input type="number" id="gpsAltInput" step="0.1" placeholder="123.5"
                 value="${currentGPS?.altitude || ''}"
                 style="width: 100%; padding: 8px; border: 1px solid #ffc107; border-radius: 4px;">
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
          <button id="saveGPSBtn" class="secondary-button" style="background: #28a745; color: white;">
            ✓ Save GPS
          </button>
          <button id="cancelGPSBtn" class="secondary-button">
            Cancel
          </button>
        </div>
      </div>
    </div>
  `;
  
  // Add event listeners
  document.getElementById('saveGPSBtn').addEventListener('click', () => {
    const lat = parseFloat(document.getElementById('gpsLatInput').value);
    const lon = parseFloat(document.getElementById('gpsLonInput').value);
    const alt = document.getElementById('gpsAltInput').value ? 
                 parseFloat(document.getElementById('gpsAltInput').value) : null;
    
    if (isNaN(lat) || isNaN(lon)) {
      alert('Please enter valid latitude and longitude values');
      return;
    }
    
    // Validate ranges
    if (lat < -90 || lat > 90) {
      alert('Latitude must be between -90 and 90');
      return;
    }
    if (lon < -180 || lon > 180) {
      alert('Longitude must be between -180 and 180');
      return;
    }
    
    const gpsData = {
      latitude: lat,
      longitude: lon,
      altitude: alt,
      source: 'Manual Entry'
    };
    
    // ✅ TWO SCENARIOS:
    // 1. AFTER AI analysis (currentAnalysisData exists) - save to metadata
    // 2. BEFORE AI analysis (on Visual Analysis page) - save to preAnalysisGPS Map
    
    if (currentAnalysisData && currentAnalysisData.metadata) {
      // Scenario 1: AFTER AI analysis - save to currentAnalysisData
      currentAnalysisData.metadata.manualGPS = gpsData;
      console.log('✅ GPS saved to currentAnalysisData.metadata.manualGPS (post-AI):', gpsData);
      
      // Redisplay GPS section
      displayGPSSection(gpsData, 'Manual Entry');
      
      // Show success message
      updateStatus('GPS coordinates updated - will apply to all cluster images on XMP generation', 'complete');
      
      // Log verification
      console.log('📍 Current analysis data after GPS save:', JSON.stringify({
        hasMetadata: !!currentAnalysisData.metadata,
        hasManualGPS: !!currentAnalysisData.metadata?.manualGPS,
        manualGPS: currentAnalysisData.metadata?.manualGPS,
        title: currentAnalysisData.metadata?.title
      }, null, 2));
    } 
    else {
      // Scenario 2: BEFORE AI analysis - save to preAnalysisGPS Map
      // Use currentClusterIndex if we're viewing a cluster
      
      if (currentClusterIndex !== null) {
        preAnalysisGPS.set(currentClusterIndex, gpsData);
        console.log(`✅ GPS saved to preAnalysisGPS Map (pre-AI) for cluster ${currentClusterIndex}:`, gpsData);
        
        // Redisplay GPS section
        displayGPSSection(gpsData, 'Manual Entry (Pre-Analysis)');
        
        // Show success message
        updateStatus(`GPS saved for cluster ${currentClusterIndex}. Will be preserved when running AI analysis.`, 'complete');
      } else {
        console.error('❌ Cannot save GPS: No current cluster index');
        alert('Error: Unable to determine which cluster to save GPS to');
      }
    }
  });
  
  document.getElementById('cancelGPSBtn').addEventListener('click', () => {
    // Restore previous display
    if (currentGPS) {
      displayGPSSection(currentGPS, source);
    } else {
      displayGPSSection(null, '');
    }
  });
}

/**
 * Populate keywords as tags
 */
function populateKeywords(keywords) {
  const container = document.getElementById('keywordsContainer');
  container.innerHTML = '';
  
  keywords.forEach(keyword => {
    const tag = createKeywordTag(keyword);
    container.appendChild(tag);
  });
}

/**
 * Create a keyword tag element
 */
function createKeywordTag(keyword) {
  const tag = document.createElement('div');
  tag.className = 'keyword-tag';
  
  const text = document.createElement('span');
  text.textContent = keyword;
  
  const remove = document.createElement('span');
  remove.className = 'keyword-remove';
  remove.textContent = '×';
  remove.onclick = () => tag.remove();
  
  tag.appendChild(text);
  tag.appendChild(remove);
  
  return tag;
}

/**
 * Display static metadata (creator, copyright, date)
 */
function displayStaticMetadata(analysisData) {
  // Extract year from EXIF or use current year
  const year = new Date().getFullYear(); // TODO: Extract from EXIF
  
  const copyrightEl = document.getElementById('copyrightDisplay');
  copyrightEl.textContent = `© ${year} Philip Ethan Grossman. All Rights Reserved.`;
  
  const dateEl = document.getElementById('dateCreatedDisplay');
  dateEl.textContent = 'From EXIF DateTimeOriginal';
}

/**
 * Add keyword from input
 */
function addKeyword() {
  const input = document.getElementById('newKeywordInput');
  const keyword = input.value.trim();
  
  if (!keyword) return;
  
  // Check if keyword already exists
  const existingKeywords = Array.from(document.querySelectorAll('.keyword-tag span:first-child'))
    .map(span => span.textContent);
  
  if (existingKeywords.includes(keyword)) {
    alert('This keyword already exists');
    return;
  }
  
  // Add keyword tag
  const container = document.getElementById('keywordsContainer');
  const tag = createKeywordTag(keyword);
  container.appendChild(tag);
  
  // Clear input
  input.value = '';
}

/**
 * Collect edited metadata from form
 */
function collectMetadataFromForm() {
  console.log('🔍 ========== COLLECTING METADATA FROM FORM ==========');
  console.log('🔍 currentAnalysisData:', currentAnalysisData ? 'EXISTS' : 'NULL');
  
  if (currentAnalysisData) {
    console.log('🔍 currentAnalysisData.metadata:', JSON.stringify({
      hasManualGPS: !!currentAnalysisData.metadata?.manualGPS,
      manualGPS: currentAnalysisData.metadata?.manualGPS,
      hasGpsAnalysis: !!currentAnalysisData.metadata?.gpsAnalysis,
      gpsAnalysis: currentAnalysisData.metadata?.gpsAnalysis,
      hasClusterGPS: !!currentAnalysisData.cluster?.mainRep?.gps,
      clusterGPS: currentAnalysisData.cluster?.mainRep?.gps
    }, null, 2));
  }
  
  // Collect all field values
  const metadata = {
    title: document.getElementById('metaTitle')?.value || '',
    description: document.getElementById('metaDescription')?.value || '',
    caption: document.getElementById('metaCaption')?.value || '',
    category: document.getElementById('metaCategory')?.value || '',
    sceneType: document.getElementById('metaSceneType')?.value || '',
    mood: document.getElementById('metaMood')?.value || '',
    altText: document.getElementById('metaAltText')?.value || '',
    
    // Location
    location: {
      city: document.getElementById('metaCity')?.value || '',
      state: document.getElementById('metaState')?.value || '',
      country: document.getElementById('metaCountry')?.value || '',
      specificLocation: document.getElementById('metaSpecificLocation')?.value || ''
    },
    
    // Keywords - collect from the keywords container
    keywords: [],
    
    // Subjects - collect from subjects container
    subjects: [],
    
    // Hashtags - collect from hashtags container
    hashtags: [],
    
    // Preserve confidence and provider info
    confidence: currentAnalysisData?.metadata?.confidence || 85,
    provider: currentAnalysisData?.metadata?.provider || 'ollama'
  };
  
  // ✅ GPS COLLECTION - Check MULTIPLE sources
  // Priority: Manual (post-AI) > Pre-Analysis > AI Analysis > EXIF
  console.log('🔍 Checking GPS from multiple sources...');
  
  // Priority 1: Manual GPS from currentAnalysisData (post-AI)
  if (currentAnalysisData?.metadata?.manualGPS?.latitude) {
    metadata.gps = currentAnalysisData.metadata.manualGPS;
    console.log('✅ Using manual GPS from currentAnalysisData:', metadata.gps);
  }
  // Priority 2: Pre-analysis GPS from Map
  else if (currentClusterIndex !== null && preAnalysisGPS.has(currentClusterIndex)) {
    metadata.gps = preAnalysisGPS.get(currentClusterIndex);
    console.log('✅ Using pre-analysis GPS from Map:', metadata.gps);
  }
  // Priority 3: AI Analysis GPS
  else if (currentAnalysisData?.metadata?.gpsAnalysis?.latitude) {
    metadata.gps = {
      latitude: parseFloat(currentAnalysisData.metadata.gpsAnalysis.latitude),
      longitude: parseFloat(currentAnalysisData.metadata.gpsAnalysis.longitude),
      altitude: currentAnalysisData.metadata.gpsAnalysis.altitude || null,
      source: 'AI Analysis'
    };
    console.log('✅ Using AI Analysis GPS:', metadata.gps);
  }
  // Priority 4: EXIF GPS
  else if (currentAnalysisData?.cluster?.mainRep?.gps?.latitude) {
    metadata.gps = currentAnalysisData.cluster.mainRep.gps;
    console.log('✅ Using EXIF GPS:', metadata.gps);
  }
  else {
    console.log('⚠️ No GPS found in any source');
  }
  
  // ✅ Collect keywords from .keyword-tag elements in AI Analysis tab
  const keywordTags = document.querySelectorAll('#keywordsContainer .keyword-tag span:first-child');
  keywordTags.forEach(span => {
    const keyword = span.textContent.trim();
    if (keyword) {
      metadata.keywords.push(keyword);
    }
  });
  
  // Collect hashtags (split by space)
  const hashtagsText = document.getElementById('metaHashtags')?.value || '';
  metadata.hashtags = hashtagsText.split(/[\s,]+/).filter(tag => tag.trim());
  
  console.log('📦 Final collected metadata:', JSON.stringify({
    title: metadata.title,
    hasGPS: !!metadata.gps,
    gps: metadata.gps,
    keywordsCount: metadata.keywords.length,
    hashtagsCount: metadata.hashtags.length
  }, null, 2));
  
  console.log('🔍 ========== END COLLECTING METADATA ==========\n');
  
  return metadata;
}

/**
 * Generate XMP files
 */
async function generateXMPFiles() {
  if (!currentAnalysisData) {
    alert('No analysis data available');
    return;
  }
  
  try {
    console.log('Generating XMP files...');
    
    // Collect edited metadata from form
    const editedMetadata = collectMetadataFromForm();
    
    // Show progress
    updateStatus('Generating XMP files...', 'processing');
    showProgress(0);
    
    // Call backend to generate XMP
    const result = await window.electronAPI.generateXMPFiles({
      cluster: currentAnalysisData.cluster,
      metadata: editedMetadata,
      affectedImages: currentAnalysisData.affectedImages
    });
    
    showProgress(100);
    
    if (result.success) {
      updateStatus('XMP files generated successfully!', 'complete');
      alert(`✅ Success! Generated ${result.count} XMP files.`);
      
      // Clear current analysis
      currentAnalysisData = null;
      
      // Return to Visual Analysis tab
      const resultsTab = document.querySelector('[data-tab="results"]');
      if (resultsTab) {
        resultsTab.click();
      }
      
    } else {
      throw new Error(result.error || 'XMP generation failed');
    }
    
  } catch (error) {
    console.error('XMP generation failed:', error);
    updateStatus(`XMP generation failed: ${error.message}`, 'error');
    alert(`XMP generation failed: ${error.message}`);
  }
}

/**
 * Re-analyze with specific provider
 */
async function reanalyzeWithProvider(provider) {
  if (!currentAnalysisData) {
    alert('No analysis data available');
    return;
  }
  
  try {
    console.log(`Re-analyzing with ${provider}...`);
    
    updateStatus(`Re-analyzing with ${provider}...`, 'processing');
    showProgress(0);
    
    // Call backend with forced provider
    const result = await window.electronAPI.analyzeClusterWithAI(
      currentAnalysisData.cluster,
      provider
    );
    
    showProgress(100);
    
    if (result.success) {
      console.log('Re-analysis complete:', result.data);
      currentAnalysisData = result.data;
      displayAIAnalysisResults(result.data);
      updateStatus('Re-analysis complete!', 'complete');
    } else {
      throw new Error(result.error || 'Re-analysis failed');
    }
    
  } catch (error) {
    console.error('Re-analysis failed:', error);
    updateStatus(`Re-analysis failed: ${error.message}`, 'error');
    alert(`Re-analysis failed: ${error.message}`);
  }
}

// ============================================
// Event Listeners for AI Analysis Tab
// ============================================

function initializeAIAnalysisListeners() {
  // Add keyword button
  const addKeywordBtn = document.getElementById('addKeywordBtn');
  if (addKeywordBtn) {
    addKeywordBtn.addEventListener('click', addKeyword);
  }
  
  // Add keyword on Enter key
  const newKeywordInput = document.getElementById('newKeywordInput');
  if (newKeywordInput) {
    newKeywordInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        addKeyword();
      }
    });
  }
  
  // Regenerate button
  const regenerateBtn = document.getElementById('regenerateBtn');
  if (regenerateBtn) {
    regenerateBtn.addEventListener('click', () => reanalyzeWithProvider('ollama'));
  }
  
  // Save metadata for current cluster button (replaces old Generate XMP button)
  const saveMetadataBtn = document.getElementById('saveMetadataBtn');
  if (saveMetadataBtn) {
    saveMetadataBtn.addEventListener('click', saveCurrentClusterMetadata);
  }
  
  // Generate All XMP button
  const generateAllXMPBtn = document.getElementById('generateAllXMPBtn');
  if (generateAllXMPBtn) {
    generateAllXMPBtn.addEventListener('click', generateAllXMPFiles);
  }
  
  // Load clusters when AI Analysis tab is clicked
  // Note: loadClustersForAnalysis() is called automatically after batch analysis
  // No need for tab click listener to avoid duplicate calls
  
  // Low confidence warning buttons
  const reanalyzeOllamaBtn = document.getElementById('reanalyzeOllamaBtn');
  if (reanalyzeOllamaBtn) {
    reanalyzeOllamaBtn.addEventListener('click', () => reanalyzeWithProvider('ollama'));
  }
  
  const analyzeGoogleBtn = document.getElementById('analyzeGoogleBtn');
  if (analyzeGoogleBtn) {
    analyzeGoogleBtn.addEventListener('click', () => reanalyzeWithProvider('google'));
  }
  
  const acceptManuallyBtn = document.getElementById('acceptManuallyBtn');
  if (acceptManuallyBtn) {
    acceptManuallyBtn.addEventListener('click', () => {
      document.getElementById('lowConfidenceWarning').style.display = 'none';
      alert('You can now edit the metadata manually before generating XMP files.');
    });
  }
  
  console.log('✅ AI Analysis listeners attached');
}

// ============================================
// Personal Data Functions
// ============================================

/**
 * Load personal data from database
 */
async function loadPersonalData() {
  try {
    const data = await window.electronAPI.getPersonalData();
    
    if (data.success && data.data) {
      document.getElementById('creatorName').value = data.data.creatorName || '';
      document.getElementById('creatorJobTitle').value = data.data.jobTitle || '';
      document.getElementById('creatorAddress').value = data.data.address || '';
      document.getElementById('creatorCity').value = data.data.city || '';
      document.getElementById('creatorState').value = data.data.state || '';
      document.getElementById('creatorPostalCode').value = data.data.postalCode || '';
      document.getElementById('creatorCountry').value = data.data.country || '';
      document.getElementById('creatorPhone').value = data.data.phone || '';
      document.getElementById('creatorEmail').value = data.data.email || '';
      document.getElementById('creatorWebsite').value = data.data.website || '';
      document.getElementById('copyrightStatus').value = data.data.copyrightStatus || 'copyrighted';
      document.getElementById('copyrightNotice').value = data.data.copyrightNotice || '';
      document.getElementById('rightsUsageTerms').value = data.data.rightsUsageTerms || '';
      
      console.log('✅ Personal data loaded');
    }
  } catch (error) {
    console.error('❌ Failed to load personal data:', error);
  }
}

/**
 * Save personal data to database
 */
async function savePersonalData() {
  const data = {
    creatorName: document.getElementById('creatorName').value,
    jobTitle: document.getElementById('creatorJobTitle').value,
    address: document.getElementById('creatorAddress').value,
    city: document.getElementById('creatorCity').value,
    state: document.getElementById('creatorState').value,
    postalCode: document.getElementById('creatorPostalCode').value,
    country: document.getElementById('creatorCountry').value,
    phone: document.getElementById('creatorPhone').value,
    email: document.getElementById('creatorEmail').value,
    website: document.getElementById('creatorWebsite').value,
    copyrightStatus: document.getElementById('copyrightStatus').value,
    copyrightNotice: document.getElementById('copyrightNotice').value,
    rightsUsageTerms: document.getElementById('rightsUsageTerms').value
  };
  
  // Validate required fields
  if (!data.creatorName || !data.email || !data.copyrightNotice) {
    alert('❌ Please fill in all required fields (marked with *)');
    return;
  }
  
  try {
    const result = await window.electronAPI.savePersonalData(data);
    
    if (result.success) {
      alert('✅ Personal data saved successfully!');
    } else {
      alert('❌ Failed to save: ' + result.error);
    }
  } catch (error) {
    console.error('❌ Failed to save personal data:', error);
    alert('❌ Error saving personal data: ' + error.message);
  }
}

// ============================================
// GPS DIAGNOSTIC FUNCTION
// ============================================

window.debugGPS = function() {
  console.log('\n\n🔍 GPS DIAGNOSTIC REPORT');
  console.log('========================\n');
  
  console.log('1. window.processedClusters:');
  if (window.processedClusters) {
    let count = 0;
    window.processedClusters.forEach((c, i) => {
      const gps = c.gps || c.mainRep?.gps;
      if (gps?.latitude) {
        count++;
        console.log(`   [${i}] ✅ ${c.representativeFilename || c.representative}: ${gps.latitude}, ${gps.longitude}`);
      }
    });
    if (count === 0) {
      console.log('   ⚪ No GPS coordinates found');
    }
  } else {
    console.log('   ❌ Not initialized');
  }
  
  console.log('\n2. allProcessedImages:');
  if (allProcessedImages) {
    let count = 0;
    allProcessedImages.forEach((g, i) => {
      const gps = g.mainRep?.gps;
      if (gps?.latitude) {
        count++;
        console.log(`   [${i}] ✅ ${g.mainRep.representativeFilename}: ${gps.latitude}, ${gps.longitude}`);
      }
    });
    if (count === 0) {
      console.log('   ⚪ No GPS coordinates found');
    }
  } else {
    console.log('   ❌ Not initialized');
  }
  
  console.log('\n3. analyzedClusters:');
  if (analyzedClusters && analyzedClusters.size > 0) {
    let count = 0;
    analyzedClusters.forEach((metadata, i) => {
      if (metadata.gpsAnalysis?.latitude) {
        count++;
        console.log(`   [${i}] ✅ GPS from AI: ${metadata.gpsAnalysis.latitude}, ${metadata.gpsAnalysis.longitude}`);
      }
      if (metadata.manualGPS?.latitude) {
        count++;
        console.log(`   [${i}] ✅ Manual GPS: ${metadata.manualGPS.latitude}, ${metadata.manualGPS.longitude}`);
      }
    });
    if (count === 0) {
      console.log('   ⚪ No GPS coordinates found');
    }
  } else {
    console.log('   ⚪ No analyzed clusters yet');
  }
  
  console.log('\n4. preAnalysisGPS Map:');
  if (preAnalysisGPS && preAnalysisGPS.size > 0) {
    preAnalysisGPS.forEach((gps, idx) => {
      console.log(`   [${idx}] ✅ ${gps.latitude}, ${gps.longitude}`);
    });
  } else {
    console.log('   ⚪ No pre-analysis GPS stored');
  }
  
  console.log('\n========================\n');
};

// ============================================
// Prompt Editor Functions
// ============================================

/**
 * Show the prompt editor modal for a specific cluster
 */
async function showPromptEditor(clusterGroup) {
  console.log('📝 Opening prompt editor for:', clusterGroup.mainRep?.representativeFilename);
  
  currentPromptCluster = clusterGroup;
  const representativePath = clusterGroup.mainRep?.representativePath;
  const filename = clusterGroup.mainRep?.representativeFilename;
  
  if (!representativePath) {
    alert('Error: Could not identify cluster for prompt editing');
    return;
  }
  
  // Update modal title and filename
  document.getElementById('promptEditorTitle').textContent = 'Edit AI Prompt';
  document.getElementById('promptEditorFilename').textContent = filename;
  
  // Check if we have a custom prompt for this cluster
  let promptText = '';
  if (customPrompts.has(representativePath)) {
    promptText = customPrompts.get(representativePath);
    console.log('📝 Using saved custom prompt');
  } else {
    // Generate default prompt
    try {
      console.log('📝 Generating default prompt...');
      const result = await window.electronAPI.generateDefaultPrompt(clusterGroup);
      if (result.success) {
        promptText = result.prompt;
        console.log('✅ Default prompt generated');
      } else {
        console.warn('⚠️ Failed to generate default prompt, using fallback');
        promptText = generateFallbackPrompt(clusterGroup);
      }
    } catch (error) {
      console.error('❌ Error generating default prompt:', error);
      promptText = generateFallbackPrompt(clusterGroup);
    }
  }
  
  // Set the textarea content
  document.getElementById('promptEditorTextarea').value = promptText;
  
  // Show the modal
  document.getElementById('promptEditorModal').style.display = 'block';
  
  // Focus the textarea
  setTimeout(() => {
    document.getElementById('promptEditorTextarea').focus();
  }, 100);
}

/**
 * Generate a fallback prompt if the backend fails
 */
function generateFallbackPrompt(clusterGroup) {
  const filename = clusterGroup.mainRep?.representativeFilename || 'Unknown';
  const keywords = clusterGroup.mainRep?.keywords || [];
  const gps = clusterGroup.mainRep?.gps;
  
  let prompt = `You are analyzing a photograph named "${filename}".\n\n`;
  
  if (keywords.length > 0) {
    prompt += `The image has these keywords: ${keywords.join(', ')}\n\n`;
  }
  
  if (gps && gps.latitude && gps.longitude) {
    prompt += `The image was taken at GPS coordinates: ${gps.latitude}, ${gps.longitude}\n\n`;
  }
  
  prompt += `Please analyze this image and provide detailed metadata including:\n`;
  prompt += `- A descriptive title\n`;
  prompt += `- Relevant keywords and tags\n`;
  prompt += `- Location information if identifiable\n`;
  prompt += `- Subject matter description\n`;
  prompt += `- Technical details if relevant\n\n`;
  prompt += `Format your response as JSON with fields: title, keywords, location, description, technicalDetails`;
  
  return prompt;
}

/**
 * Save the custom prompt for the current cluster
 */
function saveCustomPrompt() {
  const textarea = document.getElementById('promptEditorTextarea');
  const promptText = textarea.value.trim();
  
  if (!promptText) {
    alert('Prompt cannot be empty');
    return;
  }
  
  if (!currentPromptCluster) {
    alert('Error: Could not save prompt');
    return;
  }
  
  const representativePath = currentPromptCluster.mainRep?.representativePath;
  if (!representativePath) {
    alert('Error: Could not identify cluster for saving prompt');
    return;
  }
  
  // Save the custom prompt
  customPrompts.set(representativePath, promptText);
  
  console.log('💾 Saved custom prompt for:', currentPromptCluster.mainRep?.representativeFilename);
  
  // Update the button text to show it's been edited
  updatePromptButtonState(representativePath);
  
  // Close the modal
  closePromptEditor();
  
  // Show success message
  showNotification('Custom prompt saved successfully!', 'success');
}

/**
 * Close the prompt editor modal
 */
function closePromptEditor() {
  document.getElementById('promptEditorModal').style.display = 'none';
  currentPromptCluster = null;
}

/**
 * Update the prompt button state based on whether a custom prompt exists
 */
function updatePromptButtonState(representativePath) {
  // Find all prompt buttons for this cluster
  const buttons = document.querySelectorAll(`[data-cluster-path="${representativePath}"]`);
  
  buttons.forEach(button => {
    if (customPrompts.has(representativePath)) {
      button.textContent = '✏️ Edit Prompt';
      button.classList.add('editing');
    } else {
      button.textContent = 'View Prompt';
      button.classList.remove('editing');
    }
  });
}

/**
 * Analyze cluster with custom prompt if available
 */
async function analyzeClusterWithCustomPrompt(clusterGroup) {
  const representativePath = clusterGroup.mainRep?.representativePath;
  const customPrompt = customPrompts.get(representativePath);
  
  console.log('🤖 Analyzing cluster with', customPrompt ? 'custom' : 'default', 'prompt');
  
  try {
    // Show loading state
    updateStatus('Analyzing with AI...', 'processing');
    showProgress(0);
    
    // Call backend with custom prompt if available
    const result = await window.electronAPI.analyzeClusterWithAI(clusterGroup, customPrompt);
    
    showProgress(100);
    
    if (result.success) {
      console.log('✅ AI analysis complete:', result.data);
      
      // Store analysis data globally
      currentAnalysisData = result.data;
      
      // Display results in AI Analysis tab
      displayAIAnalysisResults(result.data);
      
      // Switch to AI Analysis tab
      const aiAnalysisTab = document.querySelector('[data-tab="ai-analysis"]');
      if (aiAnalysisTab) {
        aiAnalysisTab.click();
      }
      
      updateStatus('AI analysis complete!', 'complete');
      
    } else {
      throw new Error(result.error || 'AI analysis failed');
    }
    
  } catch (error) {
    console.error('❌ AI analysis failed:', error);
    updateStatus(`AI analysis failed: ${error.message}`, 'error');
    alert(`AI analysis failed: ${error.message}`);
  }
}

/**
 * Show a notification message
 */
function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  
  // Style the notification
  Object.assign(notification.style, {
    position: 'fixed',
    top: '20px',
    right: '20px',
    padding: '12px 20px',
    borderRadius: '6px',
    color: 'white',
    fontWeight: '600',
    zIndex: '10000',
    maxWidth: '300px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    transform: 'translateX(100%)',
    transition: 'transform 0.3s ease'
  });
  
  // Set background color based on type
  switch (type) {
    case 'success':
      notification.style.background = 'linear-gradient(135deg, #28a745 0%, #20c997 100%)';
      break;
    case 'error':
      notification.style.background = 'linear-gradient(135deg, #dc3545 0%, #c82333 100%)';
      break;
    case 'warning':
      notification.style.background = 'linear-gradient(135deg, #ffc107 0%, #e0a800 100%)';
      break;
    default:
      notification.style.background = 'linear-gradient(135deg, #007bff 0%, #0056b3 100%)';
  }
  
  // Add to page
  document.body.appendChild(notification);
  
  // Animate in
  setTimeout(() => {
    notification.style.transform = 'translateX(0)';
  }, 10);
  
  // Remove after 3 seconds
  setTimeout(() => {
    notification.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

// ============================================
// Application Ready
// ============================================
console.log('App.js fully loaded. Waiting for DOM...');
